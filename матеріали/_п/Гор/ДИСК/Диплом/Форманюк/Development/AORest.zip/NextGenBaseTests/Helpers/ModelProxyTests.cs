﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using NextGenBase;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NextGenBase.Extensions;
using NextGenBase.Helpers;
using WebApplication.Models;
using TypeExtensions = NextGenBase.Extensions.TypeExtensions;

namespace NextGenBase.Tests
{
    public class AccessObject<T, TResult>
    {
        public PropertyInfo PropertyInfo { get; set; }
        public Func<T, TResult> Get { get; set; }
        public Action<T, TResult> Set { get; set; }
    }

    [TestClass()]
    public class ModelProxyTests
    {
        public static Func<T, object> GetValueGetter<T>(PropertyInfo propertyInfo)
        {
            if (typeof(T) != propertyInfo.DeclaringType)
            {
                throw new ArgumentException();
            }

            var instance = Expression.Parameter(propertyInfo.DeclaringType, "i");
            var property = Expression.Property(instance, propertyInfo);
            var convert = Expression.TypeAs(property, typeof(object));
            return (Func<T, object>)Expression.Lambda(convert, instance).Compile();
        }

        public static Action<T, object> GetValueSetter<T>(PropertyInfo propertyInfo)
        {
            if (typeof(T) != propertyInfo.DeclaringType)
            {
                throw new ArgumentException();
            }

            var instance = Expression.Parameter(propertyInfo.DeclaringType, "i");
            var argument = Expression.Parameter(typeof(object), "a");
            var setterCall = Expression.Call(
                instance,
                propertyInfo.GetSetMethod(),
                Expression.Convert(argument, propertyInfo.PropertyType));
            return (Action<T, object>)Expression.Lambda(setterCall, instance, argument)
                                                .Compile();
        }

        public void BuildAccessors<T>(Type type, Dictionary<string, AccessObject<T, object>> dictionary)
        {
            type.GetProperties().ForEach(o =>
            {
                dictionary.Add(o.Name, new AccessObject<T, object>
                {
                    PropertyInfo = o,
                    Get = GetValueGetter<T>(o),
                    Set = GetValueSetter<T>(o)
                });
            });
        }

        [TestMethod()]
        public void ModelProxyTest()
        {
            Dictionary<string, AccessObject<TestDataModel, object>> _accessObjects
            = new Dictionary<string, AccessObject<TestDataModel, object>>();     

            var t = new TestDataModel
            {
                Id = 1,
                Value1 = "123",
                Value2 = "456",
                Value3 = "",
                Value4 = 55
            };

            BuildAccessors(t.GetType(), _accessObjects);
            var r = _accessObjects["Value1"].Get(t);
            _accessObjects["Value2"].Set(t, "987");
        }

        [TestMethod()]
        public void FillTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void FillTest1()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void GetEnumeratorTest()
        {
            Assert.Fail();
        }
    }
}
