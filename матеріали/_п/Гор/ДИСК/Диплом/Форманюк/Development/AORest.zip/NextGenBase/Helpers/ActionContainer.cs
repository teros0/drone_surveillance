﻿using System;
using System.Collections.Generic;
using NextGenBase.Interfaces.Servises;

namespace NextGenBase.Helpers
{
    public class ActionContainer
    {
        public List<string> Errors { get; set; }

        public List<Exception> Exceptions { get; set; }

        public object Value { get; set; }

        public ActionContainer()
        {
            this.Errors = new List<string>();
            this.Exceptions = new List<Exception>();
        }

        public bool Success
        {
            get { return (this.Errors.Count == 0); }
        }

        public void AddError(string error)
        {
            this.Errors.Add(error);
            this.Exceptions.Add(new Exception(error));
        }

        public void AddError(Exception error)
        {
            this.Errors.Add(error.Message);
            this.Exceptions.Add(error);
        }

        public static ActionContainer FromObject(object o)
        {
            return new ActionContainer { Value = o };
        }

        public static object ToObject(ActionContainer o)
        {
            return o.Value;
        }

        public ServiceLocator ServiceProvider { get { return ServiceLocator.Instance; } }    
    }

    public class ActionContainer<T> : ActionContainer
    {        
        public new T Value { get; set; }        

        public static implicit operator T(ActionContainer<T> o)
        {
            return o.Value;
        }

        public static implicit operator ActionContainer<T>(T o)
        {
            return new ActionContainer<T>{Value = o};
        }

        public static ActionContainer ToResult(ActionContainer<T> o)
        {
            return new ActionContainer
            {
                Value = o.Value,
                Errors = o.Errors,
                Exceptions = o.Exceptions               
            };
        }

        public static ActionContainer<T> FromResult(ActionContainer o)
        {
            return new ActionContainer<T>
            {
                Value = (T)o.Value,
                Errors = o.Errors,
                Exceptions = o.Exceptions
            };
        }        
    }
}