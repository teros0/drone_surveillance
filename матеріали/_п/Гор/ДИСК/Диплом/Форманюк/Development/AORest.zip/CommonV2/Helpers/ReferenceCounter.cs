﻿using System.Collections.Generic;
using System.Linq;

namespace CommonV2.Helpers
{
    /// <summary>
    /// Provide functionality to count references for provided items
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class ReferenceCounter<T> : IEnumerable<KeyValuePair<T, int>>
    {
        private Dictionary<T, int> m_innerContainer;

        /// <summary>
        /// Initializes a new instance of the <see cref="ReferenceCounter{T}"/> struct.
        /// </summary>
        public ReferenceCounter()
        {
            m_innerContainer = new Dictionary<T, int>();
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ReferenceCounter{T}"/> struct.
        /// </summary>
        /// <param name="item">The item.</param>
        public ReferenceCounter(T item)
            : this()
        {
            m_innerContainer.Add(item, 1);
        }

        /// <summary>
        /// Gets the read-only list of inner items
        /// </summary>
        /// <value>
        /// The list.
        /// </value>
        public IEnumerable<T> List { get { return m_innerContainer.Select(o => o.Key).ToList().AsReadOnly(); } }

        /// <summary>
        /// Gets the reference count for specified item.
        /// </summary>
        /// <value>
        /// The <see cref="System.Int32"/>.
        /// </value>
        /// <param name="key">The key.</param>
        /// <returns></returns>
        public int this[T key] { get { return m_innerContainer[key]; } }
        /// <summary>
        /// Decrease reference count for item.
        /// </summary>
        /// <param name="c1">The c1.</param>
        /// <param name="c2">The c2.</param>
        /// <returns>
        /// Reference count for item
        /// </returns>
        public static int operator -(ReferenceCounter<T> c1, T c2)
        {
            return c1.Remove(c2);
        }

        /// <summary>
        /// Increase reference count for item. 
        /// </summary>
        /// <param name="c1">The c1.</param>
        /// <param name="c2">The c2.</param>
        /// <returns>
        /// Reference count for item
        /// </returns>
        public static int operator +(ReferenceCounter<T> c1, T c2)
        {
            return c1.Add(c2);
        }

        /// <summary>
        /// Increase reference count for item. 
        /// </summary>
        /// <param name="item">The item.</param>
        /// <returns></returns>
        public int Add(T item)
        {
            if (!m_innerContainer.ContainsKey(item))
                m_innerContainer.Add(item, 0);

            return ++m_innerContainer[item];
        }

        /// <summary>
        /// Clears this instance.
        /// </summary>
        public void Clear()
        {
            m_innerContainer.Clear();
        }

        /// <summary>
        /// Determines whether item has references
        /// </summary>
        /// <param name="item">The item.</param>
        /// <returns></returns>
        public bool Contains(T item)
        {
            return m_innerContainer.ContainsKey(item);
        }

        /// <summary>
        /// Returns an enumerator that iterates through the collection.
        /// </summary>
        /// <returns>
        /// A <see cref="T:System.Collections.Generic.IEnumerator`1" /> that can be used to iterate through the collection.
        /// </returns>
        IEnumerator<KeyValuePair<T, int>> IEnumerable<KeyValuePair<T, int>>.GetEnumerator()
        {
            return m_innerContainer.Select(o => o).GetEnumerator();
        }

        /// <summary>
        /// Decrease reference count for item. 
        /// </summary>
        /// <param name="item">The item.</param>
        /// <returns></returns>
        public int Remove(T item)
        {
            if (m_innerContainer.ContainsKey(item))
            {
                if (m_innerContainer[item] > 1)
                    return --m_innerContainer[item];
                else
                {
                    m_innerContainer.Remove(item);
                    return 0;
                }
            }

            return -1;
        }
        /// <summary>
        /// Returns an enumerator that iterates through a collection.
        /// </summary>
        /// <returns>
        /// An <see cref="T:System.Collections.IEnumerator" /> object that can be used to iterate through the collection.
        /// </returns>
        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return m_innerContainer.Select(o => o).GetEnumerator();
        }
    }
}
