﻿namespace NextGenBase.Interfaces
{
    public interface IEntity
    {
        object GetId(object obj);
        string GetIdName(object obj);
    }

    public interface IEntity<in TEntity> : IEntity
    {
        object GetId(TEntity obj);
        string GetIdName(TEntity obj);
    }
}