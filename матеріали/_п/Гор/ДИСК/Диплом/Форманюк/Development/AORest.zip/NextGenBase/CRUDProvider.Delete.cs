﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using jetMapper.Extensions;
using NextGenBase.Attributes.Routing;
using NextGenBase.Extensions;
using NextGenBase.Helpers;
using NextGenBase.Interfaces;

namespace NextGenBase
{
    public abstract partial class CRUDProvider<T, TEntity> : IRESTDelete
    {
        #region Delete

        [System.Web.Http.HttpDelete]
        [Route("DeleteAction", typeof (IRESTDelete), "/{controller}/{id}")]
        public HttpResponseMessage DeleteAction(HttpRequestMessage request, int id)
        {            
            var result = ValidateAndInvoke(request, (ActionContainer<T> container) =>
            {                
                var entity = GetEntity(id);
                var obj = DataService.Map<TEntity, T>(entity);

                var validationResult = _delete(obj);
                if (validationResult.Success)
                {
                    DataService.Map<TEntity, T>(DataProvider.Remove(entity));
                }
                else
                {
                    Repository.Rollback();
                    container.AddError(
                        new InvalidOperationException("Action cannot be performed due to error!",
                            new AggregateException(validationResult.Errors.Select(error => new Exception(error)))));
                    return null;
                }

                Repository.SaveChanges();

                return DataService.Map<TEntity, T>(entity);                
            },
                HttpStatusCode.OK,
                Repository.Rollback,
                InterfaceTypes[Interface.Delete]);            

            return result;
        }

        [System.Web.Http.HttpDelete]
        [Route("DeleteMultipleIdsAction", typeof(IRESTDelete), "Ids/{controller}")]
        public HttpResponseMessage DeleteMultipleIdsAction(HttpRequestMessage request, IEnumerable<int> ids)
        {
            return ValidateAndInvoke(request, (ActionContainer<IEnumerable<T>> container) =>
            {                                
                var results = new List<T>();
                foreach (var id in ids)
                {
                    var entity = GetEntity(id);
                    var obj = DataService.Map<TEntity, T>(entity);

                    var validationResult = _delete(obj);
                    if (validationResult.Success)
                    {
                        results.Add(DataService.Map<TEntity, T>(DataProvider.Remove(entity)));
                    }
                    else
                    {
                        Repository.Rollback();
                        container.AddError(new InvalidOperationException("Action cannot be performed due to error!",
                            new AggregateException(validationResult.Errors.Select(error => new Exception(error)))));
                        return null;
                    }
                }                

                Repository.SaveChanges();

                return results;                
            },
                HttpStatusCode.OK,
                Repository.Rollback,
                InterfaceTypes[Interface.Delete]);            
        }

        [System.Web.Http.HttpDelete]
        [Route("DeleteMultipleEntitiesAction", typeof(IRESTDelete), "/{controller}")]
        public Task<HttpResponseMessage> DeleteMultipleEntitiesAction(HttpRequestMessage request)
        {
            var content = request.Content.ReadAsStringAsync()
                .ContinueWith(task =>
                    Parser.ToEnumerable<T>(task.Result));

            var result = ValidateAndInvokeAsync(request, async (ActionContainer<IEnumerable<T>> container) =>
            {
                try
                {
                    var results = new List<T>();
                    foreach (var validationResult in from o in await content select _delete(o))
                    {
                        if (validationResult.Success)
                        {
                            var entity = GetEntity(DataService.GetId(validationResult.Value));

                            results.Add(DataService.Map<TEntity, T>(DataProvider.Remove(entity)));
                        }
                        else
                        {
                            Repository.Rollback();
                            container.AddError(
                                new InvalidOperationException(
                                    "Action cannot be performed due to error!",
                                    new AggregateException(validationResult.Errors.Select(error => new Exception(error)))));
                            return null;
                        }
                    }
                    Repository.SaveChanges();

                    return results;
                }
                catch (Exception e)
                {
                    Repository.Rollback();
                    container.AddError(e);
                    return null;
                }
            },
                HttpStatusCode.OK,
                Repository.Rollback,
                InterfaceTypes[Interface.Delete]);

            return result;
        }

        private ActionContainer<T> _delete(T obj)
        {
            return _chainInvoker<ActionContainer<T>>(typeof(IRESTDelete), obj)
                .Apply(o => ControllerMetadatas[GetType()].CustomeServicesChain[InterfaceTypes[Interface.Get]](o));
        }

        #endregion 
    }
}