﻿using System;
using System.Collections.Generic;
using System.Linq;
using CommonV2.EventArgs;

namespace CommonV2.Interfaces
{
    /// <summary>
    /// Provides generic key-related observable container interface
    /// </summary>
    public interface IObservableContainer<T> : ILookup<int, T>, IDisposable
    {
        #region Events        
        /// <summary>
        /// Occurs on new item add.
        /// </summary>
        event EventHandler<NotificationEventArgs<T>> OnAdd;

        /// <summary>
        /// Occurs on new range add.
        /// </summary>
        event EventHandler<NotificationEventArgs<IEnumerable<T>>> OnAddRange;

        /// <summary>
        /// Occurs on element change.
        /// </summary>
        event EventHandler<NotificationChangeEventArgs<T>> OnChange;

        /// <summary>
        /// Occurs on collection related to key clear.
        /// </summary>
        event EventHandler<NotificationEventArgs<T>> OnClear;

        /// <summary>
        /// Occurs on item remove.
        /// </summary>
        event EventHandler<NotificationEventArgs<T>> OnRemove;

        /// <summary>
        /// Occurs when on range remove.
        /// </summary>
        event EventHandler<NotificationEventArgs<IEnumerable<T>>> OnRemoveRange;
        #endregion

        /// <summary>
        /// Gets or sets the <see cref="T"/> related to key.
        /// </summary>
        /// <value>
        /// The <see cref="T"/>.
        /// </value>
        /// <param name="key">The key.</param>
        /// <param name="item">The item.</param>
        /// <returns></returns>
        T this[int key, T item] { get; set; }        

        /// <summary>
        /// <para>Adds the specified key to the container.</para>   
        /// <para><remarks>If container already contains key all data related to the key will be cleared.</remarks></para>
        /// </summary>        
        /// <param name="key">The key.</param>
        /// <param name="item">The item.</param>
        void Add(int key);

        /// <summary>
        /// Adds the specified item related to key.
        /// </summary>
        /// <param name="key">The key.</param>
        /// <param name="item">The item.</param>
        void Add(int key, T item);

        /// <summary>
        /// Adds the range.
        /// </summary>
        /// <param name="key">The key.</param>
        /// <param name="items">The items.</param>
        void AddRange(int key, IEnumerable<T> items);

        /// <summary>
        /// Clears the items related to key.
        /// </summary>
        /// <param name="key">The key.</param>
        void Clear(int key);             

        /// <summary>
        /// Determines whether collection contains item related to key.
        /// </summary>
        /// <param name="key">The key.</param>
        /// <param name="item">The item.</param>
        /// <returns></returns>
        bool Contains(int key, T item);        

        /// <summary>
        /// Inserts the specified item for key.
        /// </summary>
        /// <param name="key">The key.</param>
        /// <param name="index">The index.</param>
        /// <param name="item">The item.</param>
        void Insert(int key, int index, T item);

        /// <summary>
        /// Removes the specified item from key.
        /// </summary>
        /// <param name="key">The key.</param>
        /// <param name="item">The item.</param>
        /// <returns></returns>
        bool Remove(int key, T item);

        /// <summary>
        /// Removes item at specified index from key.
        /// </summary>
        /// <param name="key">The key.</param>
        /// <param name="index">The index.</param>
        void RemoveAt(int key, int index);

        /// <summary>
        /// Removes the range.
        /// </summary>
        /// <param name="key">The key.</param>
        /// <param name="items">The items.</param>
        void RemoveRange(int key, IEnumerable<T> items);
    }        
}
