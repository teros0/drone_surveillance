﻿using System;

namespace NextGenBase.Attributes.Services
{
    [AttributeUsage(AttributeTargets.Class, AllowMultiple = true, Inherited = true)]
    public class InjectionServiceAttribute : Attribute
    {        
        public Type Service { get; private set; }
        public Type ServiceInterface { get; private  set; }

        public InjectionServiceAttribute(Type serviceInterface, Type service)
        {            
            Service = service;
            ServiceInterface = serviceInterface;
        }
    }
}