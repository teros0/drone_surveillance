﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using Binbin.Linq;
using NextGenBase.Extensions;
using NextGenBase.Interfaces.Servises;

namespace NextGenBase.Services
{
    public class DefaultQueryService<TEntity> : IQueryService<TEntity>
    {
        public class QueryParameter
        {
            public string Name { get; private set; }
            public Func<IQueryable<TEntity>, IQueryable<TEntity>> Action { get; private set; }
            public int Order { get; set; }
            public string Keyword { get; set; }            

            public QueryParameter(string name, Func<IQueryable<TEntity>, IQueryable<TEntity>> action, string keyword, int order = 0)
            {
                Name = name;
                Action = action;
                Keyword = keyword;
                Order = order;
            }
        }

        public class QueryElement
        {
            public QueryElement(QueryParameter parameter, QueryElement parent)
            {
                Children = new List<QueryElement>();
                Parameter = parameter;
                Parent = parent;
            }

            public QueryParameter Parameter { get; private set; }
            public QueryElement Parent { get; private set; }
            public List<QueryElement> Children { get; private set; }
        }

        public void Dispose()
        {
            
        }

        private List<KeyValuePair<string, QueryElement>> _keys;

        public IEnumerable<KeyValuePair<string, QueryElement>> Keys
        {
            get
            {
                return _keys;                    
            }
        }

        public virtual string[] ElementSeparator { get { return new string[] { "." }; } }

        public object Environment { get; set; }

        public IEnumerable<KeyValuePair<string, object>> Parse(HttpRequestMessage request)
        {
            var keys = request.GetQueryNameValuePairs();

            return null;
        }

        protected virtual void PreparePairs(IEnumerable<KeyValuePair<string, string>> pairs)
        {
            pairs.ForEach(p =>
            {
                var param = p.Key.Split(ElementSeparator, StringSplitOptions.None);
                var query = RegistredQueries.SingleOrDefault(o => o.Name.Equals(param.First()));
                if (query != null)
                {
                    var parameter = new QueryElement(query, null);
                    if (param.IsMultiple())
                    {
                        param.Skip(1).ForEach(c => parameter.Children.Add(
                            new QueryElement(RegistredQueries.SingleOrDefault(o => o.Name.Equals(c)), parameter)));
                    }

                    _keys.Add(new KeyValuePair<string, QueryElement>(p.Key, parameter));
                }
            });
        }



        public DefaultQueryService()
        {
            RegistredQueries = new List<QueryParameter>();
            _keys = new List<KeyValuePair<string, QueryElement>>();
        }

        protected virtual void RegisterQueries()
        {
            //RegistredQueries.Add(new QueryParameter("search", entities =>
            //{
            //    PredicateBuilder.Create()
            //}));
        }

        protected readonly List<QueryParameter> RegistredQueries; 
    }    
}