﻿using System;

namespace NextGenBase.Attributes
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
    public sealed class VersionAttribute : Attribute
    {
        public double Version { get; private set; }

        internal string StringRepresentation
        {
            get
            {
                return string.Format("v{0}", GetVersionString(Version));
            }
        }

        public VersionAttribute(double version)
        {
            Version = version;
        }

        public string GetVersionString(double d)
        {
            return (d % 1) == 0 ? d.ToString("N") : d.ToString("N0");
        }
    }
}