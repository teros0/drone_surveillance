﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using NextGenBase.Interfaces.Servises;

namespace NextGenBase.Helpers
{    
    public class ControllerMetadata<T, TEntity>
    {        
        public Dictionary<Type, LinkedList<Delegate>> AdditionalMethods {get;set;}
        public Dictionary<Type, Func<ActionContainer, ActionContainer>> CustomeServicesChain { get; internal set; }
        public Dictionary<Type, object> MethodChains { get; set; }

        public ControllerMetadata()
        {
            CustomeServicesChain = 
                new Dictionary<Type, Func<ActionContainer, ActionContainer>>();
        }
    }    
}
