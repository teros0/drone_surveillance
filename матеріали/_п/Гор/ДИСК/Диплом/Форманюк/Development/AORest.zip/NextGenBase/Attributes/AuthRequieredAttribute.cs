﻿using System;

namespace NextGenBase.Attributes
{
    [AttributeUsage(AttributeTargets.Method, AllowMultiple = false, Inherited = true)]
    public class AuthRequieredAttribute : Attribute
    {
    }
}
