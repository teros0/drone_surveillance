﻿using System;

namespace NextGenBase.Attributes.Routing
{
    [AttributeUsage(AttributeTargets.Class, AllowMultiple = true)]
    public class DisableRoutesAttribute : Attribute
    {
        public Type RouteInterface { get; private set; }

        public DisableRoutesAttribute(Type routeInterface)
        {
            RouteInterface = routeInterface;
        }
    }
}