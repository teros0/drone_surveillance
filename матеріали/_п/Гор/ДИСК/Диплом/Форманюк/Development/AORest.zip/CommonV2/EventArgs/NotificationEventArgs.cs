﻿namespace CommonV2.EventArgs
{
    /// <summary>
    /// Provide notification event data (for add and remove)
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class NotificationEventArgs<T> : System.EventArgs
    {
        /// <summary>
        /// Gets the content.
        /// </summary>
        /// <value>
        /// The content.
        /// </value>
        public T Content { get; private set; }

        /// <summary>
        /// Gets the key.
        /// </summary>
        /// <value>
        /// The key.
        /// </value>
        public int Key { get; private set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="NotificationEventArgs{T}"/> class.
        /// </summary>
        /// <param name="key">The key.</param>
        /// <param name="element">The element.</param>
        public NotificationEventArgs(int key, T element)
        {
            Key = key;
            Content = element;
        }
    }

    /// <summary>
    /// Provide notification event data (for change)
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class NotificationChangeEventArgs<T> : NotificationEventArgs<T>
    {
        /// <summary>
        /// Gets the old content.
        /// </summary>
        /// <value>
        /// The old content.
        /// </value>
        public T OldContent { get; private set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="NotificationChangeEventArgs{T}"/> class.
        /// </summary>
        /// <param name="key">The key.</param>
        /// <param name="oldItem">The old item.</param>
        /// <param name="newItem">The new item.</param>
        public NotificationChangeEventArgs(int key, T oldItem, T newItem)
            :base(key, newItem)
        {            
            OldContent = oldItem;
        }
    }
}
