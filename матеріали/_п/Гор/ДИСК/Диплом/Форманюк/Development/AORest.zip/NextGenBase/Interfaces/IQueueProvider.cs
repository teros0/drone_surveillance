﻿using System.Threading.Tasks;

namespace NextGenBase.Interfaces
{
    public interface IQueueProvider<T>
    {
        Task<T> QWorker { get; }
        
    }
}