﻿using System;

namespace NextGenBase.Attributes.Db
{
    [AttributeUsage(AttributeTargets.Property)]
    public sealed class DbFieldAttribute : Attribute
    {        
        private readonly string _name;

        // This is a positional argument
        public DbFieldAttribute(string name)
        {
            _name = name;            
        }

        public string DbFieldName { get { return _name; } }        
    }    
}
