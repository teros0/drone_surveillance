﻿using System;
using System.Linq;
using System.Reflection;

namespace NextGenBase.Extensions
{
    public static class TypeExtensions
    {
        public static MethodInfo MakeGeneric(this MethodInfo method, params Type[] types)
        {
            return method.MakeGenericMethod(types);
        }

        /// <summary>
        /// Constructs the specified type.
        /// </summary>
        /// <param name="type">The type.</param>
        /// <returns></returns>
        public static object Construct(this Type type)
        {
            return Activator.CreateInstance(type, BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public, null, null, null);
        }

        public static T Construct<T>(this Type type)
        {
            return (T)Activator.CreateInstance(type, BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public, null, null, null);
        }

        public static T Construct<T>(this Type type, params object[] args)
        {
            return (T)Activator.CreateInstance(type, BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public, null, args, null);
        }

        public static bool HasAttribute<T>(MemberInfo property)
        {
            var attribute = typeof(T);

            if (property == null)
                return false;

            if (property.GetCustomAttributes().Any(a => a.GetType() == attribute))
                return true;

            if (property.DeclaringType == null) return false;

            var interfaces = property.DeclaringType.GetInterfaces();

            return interfaces.Any(t => HasAttribute<T>(t.GetMembers().Single(o => o.Name == property.Name)));
        }
    }
}