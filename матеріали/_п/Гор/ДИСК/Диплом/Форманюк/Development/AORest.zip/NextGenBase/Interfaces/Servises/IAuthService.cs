﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using NextGenBase.Helpers;

namespace NextGenBase.Interfaces.Servises
{
    public interface IAuthService : IService
    {
        /// <summary>
        /// Method types that require authentication
        /// </summary>
        /// <value>
        /// Interface type
        /// </value>
        IEnumerable<Type> Methods { get; }

        /// <summary>
        /// Key that contains authentication token
        /// </summary>
        string Key { get; }

        /// <summary>
        /// Fail message that would be displayed on authentication failure
        /// </summary>
        string FailMessage { get; }

        /// <summary>
        /// Token validation
        /// </summary>        
        /// <param name="request"></param>
        /// <returns></returns>
        ActionContainer Auth(HttpRequestMessage request);

        object AuthData { get; }
    }

    public interface IAuthService<in TToken, TAuthData> : IAuthService
    {
        /// <summary>
        /// Token validation
        /// </summary>
        /// <param name="token">Authentication token.</param>
        /// <returns></returns>
        ActionContainer<TAuthData> Auth(TToken token);

        new TAuthData AuthData { get; }
    }    
}