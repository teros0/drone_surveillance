﻿using System;
using System.Collections.Generic;
using System.Data.Entity.SqlServer;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NextGen.Helpers;
using Microsoft.VisualStudio.TestTools.UnitTesting;
namespace NextGen.Helpers.Tests
{
#if DEBUG
    [TestClass()]
    public class RozkladAPIParserTests
    {
        public void FixEfProviderServicesProblem()
        {
            var instance = SqlProviderServices.Instance;
        }

        [TestMethod()]
        public void RozkladAPIParserTest()
        {
            //new RozkladAPIParser(20, 20142015);
        }
    }
#endif
}
