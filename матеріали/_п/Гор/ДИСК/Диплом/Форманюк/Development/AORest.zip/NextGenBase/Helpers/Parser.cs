﻿using System.Collections.Generic;
using fastJSON;
using Newtonsoft.Json;

namespace NextGenBase.Helpers
{
    public static class Parser
    {
        public static object ParseJSON(string str)
        {
            return fastJSON.JSON.ToObject(str);
        }

        public static T ParseJSON<T>(string str)
        {            
            return fastJSON.JSON.ToObject<T>(str);
        }

        public static Dictionary<T, TR> ParseJSONToDictionary<T, TR>(string json)
        {
            return (Dictionary<T, TR>)fastJSON.JSON.Parse(json);
        }

        public static Dictionary<T, object> ParseJSONToDictionary<T>(string json)
        {
            return (Dictionary<T, object>)fastJSON.JSON.Parse(json);
        }

        public static IEnumerable<T> ToEnumerable<T>(string json)
        {
            if (!(json.StartsWith("[") && json.EndsWith("]"))) json = "[" + json + "]";

            return JsonConvert.DeserializeObject<IEnumerable<T>>(json);
        }
    }
}