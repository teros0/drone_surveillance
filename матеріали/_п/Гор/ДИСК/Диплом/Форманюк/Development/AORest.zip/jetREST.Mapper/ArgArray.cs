﻿using System.Linq;

namespace jetREST.Mapper
{
    public class ArgArray
    {
        private readonly object[] _argArray;

        public ArgArray(params object[] args)
        {
            this._argArray = args;
        }

        public override bool Equals(object obj)
        {
            // cast object to object array
            ArgArray comparedObject = obj as ArgArray;
            if (comparedObject == null) return false;

            // compare the array lengths
            if (comparedObject._argArray.Length == this._argArray.Length)
            {
                return !_argArray.Where((t, i) => !t.Equals(comparedObject._argArray[i])).Any();
            }
            else
                return false;
        }

        public override int GetHashCode()
        {
            // calculate new hashcode for argument array

            var hash = this._argArray.Sum((arg) => arg.GetHashCode());

            return hash + hash / _argArray.First().GetHashCode();
        }
    }
}
