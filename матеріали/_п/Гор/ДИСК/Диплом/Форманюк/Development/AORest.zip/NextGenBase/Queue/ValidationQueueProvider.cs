﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NextGenBase.Queue
{
    public class ValidationQueueProvider<T> : QueueProvider<T, bool, List<bool>, ValidationQueueProvider<T>>
        where T : class
    {
        private ValidationQueueProvider(T obj)
            : base(obj)
        {
            Lock = new object();
        }

        protected override List<bool> QueueProsessing(params object[] args)
        {
            var result = new List<bool>();
            Func<T, bool> act;
            while (Queue.TryDequeue(out act))
            {
                result.Add(act(Tag));
            }
            return result;
        }
    }    
}
