﻿using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace CommonV2.APIClient
{
    public class UrlBuilder
    {
        public static string APIEndPoint = "http://localhost:14785/api/";
        public static string APIRequestArgumentPattern = "{argument}={value}";  

        public string APIRoot { get; set; }

        public bool Encript { get; set; }

        private Regex _regexHolder;

        public UrlBuilder()
        {
#if DEBUG
            Encript = false;
#else
            Encript = true;
#endif
            APIRoot = "";
            _regexHolder = new Regex(@"({[A-z]+})=({[A-z]+})");
        }

        public UrlBuilder(string apiRoot)
            :this()
        {
            APIRoot = apiRoot;
        }

        public string Build(string controller, string method, IEnumerable<KeyValuePair<string, string>> parameters)
        {
            StringBuilder builder = new StringBuilder();
            StringBuilder headBuilder = new StringBuilder();
            headBuilder.Append(APIRoot + "/");
            headBuilder.Append(controller + "/");
            headBuilder.Append(method + "?");

            if (Encript)
            {
                List<string> strings = parameters.Select(o => o.Value).ToList();
                string sharedKey = strings.Last();
                strings.Remove(sharedKey);

                builder.Append("value=");
                builder.Append(Security.Encrypt(string.Join("|", strings), sharedKey));
                builder.Append(" : ");
                builder.Append(sharedKey);
            }
            else
            {
                foreach (var param in parameters)
                {
                    var match = _regexHolder.Match(APIRequestArgumentPattern);
                    builder.Append(APIRequestArgumentPattern.Replace(match.Groups[1].Value, param.Key).Replace(match.Groups[2].Value, param.Value));
                    builder.Append("&");
                }                                
            }

            return headBuilder.ToString() + builder.ToString();
        }

        public string Build(string controller, string method, IEnumerable<string> parameters)
        {
            List<KeyValuePair<string, string>> lst = new List<KeyValuePair<string, string>>();
            foreach (var item in parameters)
            {
                var temp = item.Split(new[]{'|'});
                lst.Add(new KeyValuePair<string, string>(temp[0], temp[1]));
            }

            return Build(controller, method, lst);
        }
    }
}
