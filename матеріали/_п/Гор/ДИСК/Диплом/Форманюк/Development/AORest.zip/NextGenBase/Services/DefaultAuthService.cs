﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using jetMapper.Extensions;
using NextGenBase.Extensions;
using NextGenBase.Helpers;
using NextGenBase.Interfaces;
using NextGenBase.Interfaces.Servises;

namespace NextGenBase.Services
{
    public class DefaultAuthService : IAuthService<string, object[]>
    {        
        public object[] AuthData { get; private set; }

        public virtual IEnumerable<Type> Methods
        {
            get { return new List<Type>(); }
        }

        /// <summary>
        /// Key that contains authentication token
        /// </summary>
        public virtual string Key
        {
            get { return "auth-api"; }
        }

        public virtual string FailMessage
        {
            get { return string.Format("Authorization token should be provided through {0} header", Key); }
        }

        public virtual ActionContainer Auth(HttpRequestMessage request)
        {
            IEnumerable<string> values;
            if (!request.Headers.TryGetValues(Key, out values))
            {
                AuthData = new object[] { false, null };

                return ActionContainer.FromObject(AuthData)
                    .Apply(o => o.AddError(FailMessage));
            }

            return Auth(values.Single());
        }

        public virtual ActionContainer<object[]> Auth(string token)
        {
            AuthData = new object[] { true, token };
            return AuthData;
        }

        object IAuthService.AuthData
        {
            get { return AuthData; }
        }        

        void IDisposable.Dispose()
        {
            
        }

        public object Environment
        {
            get;
            set;
        }
    }
}
