namespace NextGenBase
{
    public enum Interface
    {
        Get,
        Post,
        Put,
        Patch,
        Delete,
        Search,
        Reference
    }
}