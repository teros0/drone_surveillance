﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using jetMapper.Extensions;
using NextGenBase.Helpers;
using NextGenBase.Interfaces.Servises;
using NextGenBase.Extensions;

namespace NextGenBase
{
    public sealed class ServiceLocator : GenericSingleton<ServiceLocator>
    {
        public class Services : IEnumerable<KeyValuePair<Type, Type>>
        {
            readonly Dictionary<Type, Type> _services;

            public Services()
            {
                _services = new Dictionary<Type, Type>();
            }

            public Type this[Type type]
            {
                get { return _services[type]; }
                set { _services[type] = value; }
            }

            public IEnumerator<KeyValuePair<Type, Type>> GetEnumerator()
            {
                return _services.GetEnumerator();
            }

            IEnumerator IEnumerable.GetEnumerator()
            {
                return GetEnumerator();
            }
        }

        readonly Dictionary<Type, Services> _locatedServices;

        private ServiceLocator()
        {
            _locatedServices = new Dictionary<Type, Services>();
        }

        public ServiceLocator LocateService(Type controller, Type @interface, Type service)
        {
            if (!_locatedServices.ContainsKey(controller))
                _locatedServices.Add(controller, new Services());

            _locatedServices[controller][@interface] = service;
            return this;
        }

        public TInterface GetService<TInterface>(object controllerSelector)
            where TInterface : class, IService 
        {
            var type = typeof(TInterface);
            var controller = controllerSelector.GetType();

            try
            {
                var controllerServices = _locatedServices[controller];
                if (controllerServices.All(o => o.Key.GUID != type.GUID))
                    throw new ApplicationException("The requested service is not registered");

                return ((TInterface)Activator.CreateInstance(controllerServices.Last(o => o.Key.GUID == type.GUID).Value))
                    .Apply(o => o.Environment = controllerSelector);                
            }
            catch (Exception ex)
            {
                throw new ApplicationException(string.Format("The requested service of type \"{0}\" was not able to initialize", type), ex);
            }
        }

        public Services GetServices(object controller)
        {
            return _locatedServices[controller.GetType()];
        }
    }
}