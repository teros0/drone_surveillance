﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Routing;
using System.Web.Routing;
using NextGenBase.Routing;

namespace NextGenBase.Extensions
{
    public static class RouteExtensions
    {
        /// <summary>
        /// Maps the HTTP route.
        /// </summary>
        /// <param name="routes">The routes.</param>
        /// <param name="name">The name.</param>
        /// <param name="routeTemplate">The route template.</param>
        /// <param name="defaults">The defaults.</param>
        /// <param name="constraints">The constraints.</param>
        /// <param name="dataTokens">The data tokens.</param>
        /// <returns></returns>
        public static IHttpRoute MapHttpRoute(this HttpRouteCollection routes, string name, string routeTemplate, object defaults, object constraints, object dataTokens)
        {
            var defaultsDictionary = new HttpRouteValueDictionary(defaults);
            var constraintsDictionary = new HttpRouteValueDictionary(constraints);
            var dataTokensDictionary = new HttpRouteValueDictionary(dataTokens);
            var route = routes.CreateRoute(routeTemplate, defaultsDictionary, constraintsDictionary, dataTokens: dataTokensDictionary);
            routes.Add(name, route);
            return route;
        }

        public static TypedRoute TypedRoute(this HttpConfiguration config, string template, Action<TypedRoute> configSetup)
        {
            var route = new TypedRoute(template);
            configSetup(route);

            if (TypedDirectRouteProvider.Routes.ContainsKey(route.ControllerType))
            {
                var controllerLevelDictionary = TypedDirectRouteProvider.Routes[route.ControllerType];
                controllerLevelDictionary.Add(route.ActionName, route);
            }
            else
            {
                var controllerLevelDictionary = new Dictionary<string, TypedRoute> { { route.ActionName, route } };
                TypedDirectRouteProvider.Routes.Add(route.ControllerType, controllerLevelDictionary);
            }

            return route;
        }

        public static TypedRoute TypedRoute(this RouteCollection config, string template, Action<TypedRoute> configSetup)
        {
            var route = new TypedRoute(template);
            configSetup(route);

            if (TypedDirectRouteProvider.Routes.ContainsKey(route.ControllerType))
            {
                var controllerLevelDictionary = TypedDirectRouteProvider.Routes[route.ControllerType];
                controllerLevelDictionary.Add(route.ActionName, route);
            }
            else
            {
                var controllerLevelDictionary = new Dictionary<string, TypedRoute> { { route.ActionName, route } };
                TypedDirectRouteProvider.Routes.Add(route.ControllerType, controllerLevelDictionary);
            }

            return route;
        }

        //public static TypedRoute TypedRoute(this HttpConfiguration config, string template, Action<TypedRoute, Type> configSetup)
        //{
        //    var route = new TypedRoute(template);
        //    configSetup(route);

        //    if (TypedDirectRouteProvider.Routes.ContainsKey(route.ControllerType))
        //    {
        //        var controllerLevelDictionary = TypedDirectRouteProvider.Routes[route.ControllerType];
        //        controllerLevelDictionary.Add(route.ActionName, route);
        //    }
        //    else
        //    {
        //        var controllerLevelDictionary = new Dictionary<string, TypedRoute> { { route.ActionName, route } };
        //        TypedDirectRouteProvider.Routes.Add(route.ControllerType, controllerLevelDictionary);
        //    }

        //    return route;
        //}
    }
}
