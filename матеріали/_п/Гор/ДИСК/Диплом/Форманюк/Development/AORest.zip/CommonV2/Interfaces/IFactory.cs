﻿namespace CommonV2.Interfaces
{
    public interface IFactory<T>
    {
        T Create();
    }
}