
-- --------------------------------------------------
-- Entity Designer DDL Script for SQL Server 2005, 2008, 2012 and Azure
-- --------------------------------------------------
-- Date Created: 06/04/2015 02:19:10
-- Generated from EDMX file: D:\home\diploma\development\nextgen\DAL\RozkladDatamodel.edmx
-- --------------------------------------------------

SET QUOTED_IDENTIFIER OFF;
GO
USE [db443fdf8a800f4305abf6a44f00e1127f];
GO
IF SCHEMA_ID(N'dbo') IS NULL EXECUTE(N'CREATE SCHEMA [dbo]');
GO

-- --------------------------------------------------
-- Dropping existing FOREIGN KEY constraints
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[FK_ScheduleList_ToScheduleListItem]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ScheduleListSet] DROP CONSTRAINT [FK_ScheduleList_ToScheduleListItem];
GO
IF OBJECT_ID(N'[dbo].[FK_Test2Data_ToTestData]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Test2Data] DROP CONSTRAINT [FK_Test2Data_ToTestData];
GO
IF OBJECT_ID(N'[dbo].[FK_ScheduleListCustomScheduleItems]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ScheduleListSet_CustomScheduleItems] DROP CONSTRAINT [FK_ScheduleListCustomScheduleItems];
GO
IF OBJECT_ID(N'[dbo].[FK_CustomScheduleItems_inherits_ScheduleList]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ScheduleListSet_CustomScheduleItems] DROP CONSTRAINT [FK_CustomScheduleItems_inherits_ScheduleList];
GO

-- --------------------------------------------------
-- Dropping existing tables
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[ScheduleListSet]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ScheduleListSet];
GO
IF OBJECT_ID(N'[dbo].[ScheduleListItem]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ScheduleListItem];
GO
IF OBJECT_ID(N'[dbo].[Test2Data]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Test2Data];
GO
IF OBJECT_ID(N'[dbo].[TestData]', 'U') IS NOT NULL
    DROP TABLE [dbo].[TestData];
GO
IF OBJECT_ID(N'[dbo].[ScheduleListSet_CustomScheduleItems]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ScheduleListSet_CustomScheduleItems];
GO

-- --------------------------------------------------
-- Creating all tables
-- --------------------------------------------------

-- Creating table 'ScheduleListSet'
CREATE TABLE [dbo].[ScheduleListSet] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Code] nchar(40)  NULL,
    [DisciplineName] nvarchar(max)  NULL,
    [DisciplineShortName] nvarchar(max)  NULL,
    [DisciplineCodeRNP] nchar(40)  NULL,
    [Day] int  NULL,
    [Pair] smallint  NULL,
    [Week] smallint  NULL,
    [Room] nchar(20)  NULL,
    [Location] nvarchar(max)  NULL,
    [BeginningWeek] int  NULL,
    [EndWeek] int  NULL,
    [ClassType] nchar(10)  NULL,
    [Group] nchar(10)  NULL,
    [ScheduleListItemId] int  NULL,
    [LecturerId] int  NOT NULL
);
GO

-- Creating table 'ScheduleListItem'
CREATE TABLE [dbo].[ScheduleListItem] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Code] nchar(40)  NULL,
    [SemesterType] nchar(40)  NULL,
    [Faculty] nvarchar(max)  NULL,
    [Course] smallint  NULL
);
GO

-- Creating table 'Test2Data'
CREATE TABLE [dbo].[Test2Data] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Value3] nchar(10)  NULL,
    [Value4] int  NOT NULL
);
GO

-- Creating table 'TestData'
CREATE TABLE [dbo].[TestData] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Value1] nchar(10)  NULL,
    [Value2] nchar(10)  NULL
);
GO

-- Creating table 'LecturerSet'
CREATE TABLE [dbo].[LecturerSet] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Name] nvarchar(max)  NOT NULL,
    [Code] nvarchar(max)  NOT NULL,
    [ScheduleListId] int  NOT NULL
);
GO

-- Creating table 'ScheduleListSet_CustomScheduleItems'
CREATE TABLE [dbo].[ScheduleListSet_CustomScheduleItems] (
    [ScheduleListId] int  NULL,
    [StartTimeStamp] bigint  NOT NULL,
    [EndTimeStamp] bigint  NOT NULL,
    [Global] bit  NOT NULL,
    [Actuality] bit  NOT NULL,
    [UserId] int  NOT NULL,
    [Description] nvarchar(max)  NOT NULL,
    [ChangeTimeStamp] bigint  NOT NULL,
    [Id] int  NOT NULL
);
GO

-- --------------------------------------------------
-- Creating all PRIMARY KEY constraints
-- --------------------------------------------------

-- Creating primary key on [Id] in table 'ScheduleListSet'
ALTER TABLE [dbo].[ScheduleListSet]
ADD CONSTRAINT [PK_ScheduleListSet]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'ScheduleListItem'
ALTER TABLE [dbo].[ScheduleListItem]
ADD CONSTRAINT [PK_ScheduleListItem]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'Test2Data'
ALTER TABLE [dbo].[Test2Data]
ADD CONSTRAINT [PK_Test2Data]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'TestData'
ALTER TABLE [dbo].[TestData]
ADD CONSTRAINT [PK_TestData]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'LecturerSet'
ALTER TABLE [dbo].[LecturerSet]
ADD CONSTRAINT [PK_LecturerSet]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'ScheduleListSet_CustomScheduleItems'
ALTER TABLE [dbo].[ScheduleListSet_CustomScheduleItems]
ADD CONSTRAINT [PK_ScheduleListSet_CustomScheduleItems]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- --------------------------------------------------
-- Creating all FOREIGN KEY constraints
-- --------------------------------------------------

-- Creating foreign key on [ScheduleListItemId] in table 'ScheduleListSet'
ALTER TABLE [dbo].[ScheduleListSet]
ADD CONSTRAINT [FK_ScheduleList_ToScheduleListItem]
    FOREIGN KEY ([ScheduleListItemId])
    REFERENCES [dbo].[ScheduleListItem]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ScheduleList_ToScheduleListItem'
CREATE INDEX [IX_FK_ScheduleList_ToScheduleListItem]
ON [dbo].[ScheduleListSet]
    ([ScheduleListItemId]);
GO

-- Creating foreign key on [Value4] in table 'Test2Data'
ALTER TABLE [dbo].[Test2Data]
ADD CONSTRAINT [FK_Test2Data_ToTestData]
    FOREIGN KEY ([Value4])
    REFERENCES [dbo].[TestData]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Test2Data_ToTestData'
CREATE INDEX [IX_FK_Test2Data_ToTestData]
ON [dbo].[Test2Data]
    ([Value4]);
GO

-- Creating foreign key on [ScheduleListId] in table 'ScheduleListSet_CustomScheduleItems'
ALTER TABLE [dbo].[ScheduleListSet_CustomScheduleItems]
ADD CONSTRAINT [FK_ScheduleListCustomScheduleItems]
    FOREIGN KEY ([ScheduleListId])
    REFERENCES [dbo].[ScheduleListSet]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ScheduleListCustomScheduleItems'
CREATE INDEX [IX_FK_ScheduleListCustomScheduleItems]
ON [dbo].[ScheduleListSet_CustomScheduleItems]
    ([ScheduleListId]);
GO

-- Creating foreign key on [LecturerId] in table 'ScheduleListSet'
ALTER TABLE [dbo].[ScheduleListSet]
ADD CONSTRAINT [FK_LecturerScheduleList]
    FOREIGN KEY ([LecturerId])
    REFERENCES [dbo].[LecturerSet]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_LecturerScheduleList'
CREATE INDEX [IX_FK_LecturerScheduleList]
ON [dbo].[ScheduleListSet]
    ([LecturerId]);
GO

-- Creating foreign key on [Id] in table 'ScheduleListSet_CustomScheduleItems'
ALTER TABLE [dbo].[ScheduleListSet_CustomScheduleItems]
ADD CONSTRAINT [FK_CustomScheduleItems_inherits_ScheduleList]
    FOREIGN KEY ([Id])
    REFERENCES [dbo].[ScheduleListSet]
        ([Id])
    ON DELETE CASCADE ON UPDATE NO ACTION;
GO

-- --------------------------------------------------
-- Script has ended
-- --------------------------------------------------