﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NextGenBase.Queue
{
    public class UpdateQueueProvider<T> : QueueProvider<T, T, List<T>, UpdateQueueProvider<T>> 
        where T : class
    {
        private UpdateQueueProvider(T obj, params object[] args) 
            : base(obj, args)
        {
            Lock = new object();            
        }

        protected override List<T> QueueProsessing(params object[] args)
        {
            if(!(args.First() is DbContext))
                throw new ArgumentException();

            var result = new List<T>();
            Func<T, T> act;
            while (Queue.TryDequeue(out act))
            {
                result.Add(act(Tag));
            }
            return result;
        }
    }
}
