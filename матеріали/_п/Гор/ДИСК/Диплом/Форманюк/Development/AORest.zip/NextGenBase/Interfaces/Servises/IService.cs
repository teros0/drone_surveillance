﻿using System;
using System.ComponentModel;

namespace NextGenBase.Interfaces.Servises
{    
    public interface IService : IDisposable
    {
        object Environment { get; set; }
    }
}

