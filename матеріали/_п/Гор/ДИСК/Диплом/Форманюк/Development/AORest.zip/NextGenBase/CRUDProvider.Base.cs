﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.Http;
using System.Web.Routing;
using NextGenBase.Attributes.Services;
using NextGenBase.Extensions;
using NextGenBase.Interfaces.Servises;
using NextGenBase.Routing;
using RAMLSharp.Configuration;
using IServiceProvider = NextGenBase.Interfaces.Servises.IServiceProvider;

namespace NextGenBase
{
    public abstract class CRUDProvider : ApiController, IServiceProvider
    {
        public static string TypeOfView { get; protected set; }

        protected CRUDProvider()
        {
            ((IServiceProvider)this).Services = new Dictionary<Type, IService>();
            _createdServices = ((IServiceProvider)this).Services;

            _dataService = new Lazy<IDataService>(GetService<IDataService>);
            _dataPresenterService = new Lazy<IDataPresentationService>(GetService<IDataPresentationService>);
            _authService = new Lazy<IAuthService>(GetService<IAuthService>);
        }

        public new void Dispose()
        {
            base.Dispose();
            _createdServices.ForEach(s => s.Value.Dispose());
        }

        #region Chains

        private static IEnumerable<Type> _chainsProvider(IEnumerable<Type> types)
        {
            return types.Apply(type =>
            {
                if (type.BaseType == null && type.BaseType != typeof(CRUDProvider<,>)) return;

                type.BaseType.GetMethod("_initControllerMetadata", BindingFlags.Static | BindingFlags.NonPublic)
                    .Invoke(null, new object[] { type });
            });
        }

        #endregion

        #region Routes

        public static void Configure(HttpConfiguration config)
        {
            Configure(config, Assembly.GetCallingAssembly());
        }

        public static void Configure(HttpConfiguration config, Assembly assembly)
        {
            config.MapHttpAttributeRoutes(new TypedDirectRouteProvider());
            config.SetDocumentationProvider(new XmlDocumentationProvider(HttpContext.Current.Server.MapPath("~/App_Data/XmlDocument.xml")));

            var interfaceType = typeof(CRUDProvider);
            var types = assembly.GetTypes()
                .Where(interfaceType.IsAssignableFrom)
                .Where(o => typeof(CRUDProvider<,>) != o)
                .Where(o => o.Name.Contains("Controller"));

            _chainsProvider(types)
                .Apply(LocateServices)
                .ForEach(type =>
                {
                    if (type.BaseType == null) return;

                    type.BaseType.GetMethod("Route", BindingFlags.NonPublic | BindingFlags.Static)
                        .Invoke(null, new object[] { RouteTable.Routes, config, type });
                });
        }

        #endregion

        #region Services

        private readonly Dictionary<Type, IService> _createdServices;        

        Dictionary<Type, IService> IServiceProvider.Services { get; set; }

        public TInterface GetService<TInterface>() 
            where TInterface : class, IService
        {
            var type = typeof(TInterface);

            try
            {
                return (TInterface)(_createdServices.ContainsKey(type) ? _createdServices[type] :
                     _createdServices[type] = (IService)ServiceLocator.Instance.GetService<TInterface>(this));
            }
            catch (Exception ex)
            {
                throw new ApplicationException(string.Format("The requested service of type \"{0}\" was not able to initialize", type), ex);
            }
        }

        public void ReleaseService<TInterface>() where TInterface : class, IService
        {
            GetService<TInterface>().Dispose();
        }

        private static void LocateServices(Type type)
        {
            type.GetCustomAttributes<ServiceAttribute>(true)
                .Reverse()
                .ForEach(o => ServiceLocator.Instance.LocateService(type, o.ServiceInterface, o.Service));
        }

        #region ConscreteServices

        private readonly Lazy<IAuthService> _authService;
        private readonly Lazy<IDataPresentationService> _dataPresenterService;
        private readonly Lazy<IDataService> _dataService;

        protected IAuthService AuthService
        {
            get { return _authService.Value; }
        }

        protected IDataPresentationService DataPresenterService
        {
            get { return _dataPresenterService.Value; }
        }

        protected IDataService DataService
        {
            get { return _dataService.Value; }
        }

        #endregion

        #endregion
    }
}