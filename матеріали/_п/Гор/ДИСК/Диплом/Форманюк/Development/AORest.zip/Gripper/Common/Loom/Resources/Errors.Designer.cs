﻿// ----------------------------------------------------------------
// * The LOOM.NET project http://rapier-loom.net *
// (C) Copyright by Wolfgang Schult. All rights reserved. 
// This code is licensed under the Apache License 2.0
// To get more information, go to http://loom.codeplex.com/license
// ----------------------------------------------------------------

namespace Loom.Resources {
    using System;
    
    
    /// <summary>
    ///   Eine stark typisierte Ressourcenklasse zum Suchen von lokalisierten Zeichenfolgen usw.
    /// </summary>
    // Diese Klasse wurde von der StronglyTypedResourceBuilder automatisch generiert
    // -Klasse über ein Tool wie ResGen oder Visual Studio automatisch generiert.
    // Um einen Member hinzuzufügen oder zu entfernen, bearbeiten Sie die .ResX-Datei und führen dann ResGen
    // mit der /str-Option erneut aus, oder Sie erstellen Ihr VS-Projekt neu.
    [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0")]
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
    [global::System.Runtime.CompilerServices.CompilerGeneratedAttribute()]
    internal class Errors {
        
        private static global::System.Resources.ResourceManager resourceMan;
        
        private static global::System.Globalization.CultureInfo resourceCulture;
        
        [global::System.Diagnostics.CodeAnalysis.SuppressMessageAttribute("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        internal Errors() {
        }
        
        /// <summary>
        ///   Gibt die zwischengespeicherte ResourceManager-Instanz zurück, die von dieser Klasse verwendet wird.
        /// </summary>
        [global::System.ComponentModel.EditorBrowsableAttribute(global::System.ComponentModel.EditorBrowsableState.Advanced)]
        internal static global::System.Resources.ResourceManager ResourceManager {
            get {
                if (object.ReferenceEquals(resourceMan, null)) {
                    global::System.Resources.ResourceManager temp = new global::System.Resources.ResourceManager("Loom.Resources.Errors", typeof(Errors).Assembly);
                    resourceMan = temp;
                }
                return resourceMan;
            }
        }
        
        /// <summary>
        ///   Überschreibt die CurrentUICulture-Eigenschaft des aktuellen Threads für alle
        ///   Ressourcenzuordnungen, die diese stark typisierte Ressourcenklasse verwenden.
        /// </summary>
        [global::System.ComponentModel.EditorBrowsableAttribute(global::System.ComponentModel.EditorBrowsableState.Advanced)]
        internal static global::System.Globalization.CultureInfo Culture {
            get {
                return resourceCulture;
            }
            set {
                resourceCulture = value;
            }
        }
        
        /// <summary>
        ///   Sucht eine lokalisierte Zeichenfolge, die Can&apos;t interweave &apos;{0}&apos;: The aspect already defines an introduction method for interface method {1}. ähnelt.
        /// </summary>
        internal static string ERR_0001 {
            get {
                return ResourceManager.GetString("ERR_0001", resourceCulture);
            }
        }
        
        /// <summary>
        ///   Sucht eine lokalisierte Zeichenfolge, die Invalid aspect parameter &apos;{0}&apos; in method &apos;{1}&apos;: An unspecified aspect parameter is not allowed. ähnelt.
        /// </summary>
        internal static string ERR_0002 {
            get {
                return ResourceManager.GetString("ERR_0002", resourceCulture);
            }
        }
        
        /// <summary>
        ///   Sucht eine lokalisierte Zeichenfolge, die Can&apos;t interweave &apos;{0}&apos;: The target class &apos;{1}&apos; already defines the interface {2}. Try option &apos;{3}&apos; to resolve this. ähnelt.
        /// </summary>
        internal static string ERR_0003 {
            get {
                return ResourceManager.GetString("ERR_0003", resourceCulture);
            }
        }
        
        /// <summary>
        ///   Sucht eine lokalisierte Zeichenfolge, die Invalid aspect parameter &apos;{0}&apos; in method &apos;{1}&apos;: &apos;{3}&apos; is not allowed in this context. ähnelt.
        /// </summary>
        internal static string ERR_0004 {
            get {
                return ResourceManager.GetString("ERR_0004", resourceCulture);
            }
        }
        
        /// <summary>
        ///   Sucht eine lokalisierte Zeichenfolge, die Invalid aspect parameter &apos;{0}&apos; in method &apos;{1}&apos;: The expected type was &apos;{2}&apos;. ähnelt.
        /// </summary>
        internal static string ERR_0005 {
            get {
                return ResourceManager.GetString("ERR_0005", resourceCulture);
            }
        }
        
        /// <summary>
        ///   Sucht eine lokalisierte Zeichenfolge, die Invalid aspect method &apos;{0}&apos;: There is more than one aspect-method attribute defined ähnelt.
        /// </summary>
        internal static string ERR_0006 {
            get {
                return ResourceManager.GetString("ERR_0006", resourceCulture);
            }
        }
        
        /// <summary>
        ///   Sucht eine lokalisierte Zeichenfolge, die Only interfaces can be introduced. ähnelt.
        /// </summary>
        internal static string ERR_0007 {
            get {
                return ResourceManager.GetString("ERR_0007", resourceCulture);
            }
        }
        
        /// <summary>
        ///   Sucht eine lokalisierte Zeichenfolge, die Invalid aspect method &apos;{0}&apos;: initializers are expected to be &apos;void&apos; ähnelt.
        /// </summary>
        internal static string ERR_0008 {
            get {
                return ResourceManager.GetString("ERR_0008", resourceCulture);
            }
        }
        
        /// <summary>
        ///   Sucht eine lokalisierte Zeichenfolge, die {0} introduces interface {1} but doesn&apos;t implement method {2}. ähnelt.
        /// </summary>
        internal static string ERR_0009 {
            get {
                return ResourceManager.GetString("ERR_0009", resourceCulture);
            }
        }
        
        /// <summary>
        ///   Sucht eine lokalisierte Zeichenfolge, die Invalid parameter declaration in method {0}.{1}: The aspect parameter {2} could occour only at the beginning of the parameter list. ähnelt.
        /// </summary>
        internal static string ERR_0010 {
            get {
                return ResourceManager.GetString("ERR_0010", resourceCulture);
            }
        }
        
        /// <summary>
        ///   Sucht eine lokalisierte Zeichenfolge, die The aspect method &apos;{0}&apos; mustn&apos;t return a value: Aspect methods except some Advice.Around and Advice.AfterThrowing methods are expected to be &apos;void&apos;. ähnelt.
        /// </summary>
        internal static string ERR_0011 {
            get {
                return ResourceManager.GetString("ERR_0011", resourceCulture);
            }
        }
        
        /// <summary>
        ///   Sucht eine lokalisierte Zeichenfolge, die The aspect method &apos;{0}&apos; mustn&apos;t return &apos;{1}&apos;: The return type of {2} methods (annotated with pointcut attributes) is expected to be a generic type. ähnelt.
        /// </summary>
        internal static string ERR_0012 {
            get {
                return ResourceManager.GetString("ERR_0012", resourceCulture);
            }
        }
        
        /// <summary>
        ///   Sucht eine lokalisierte Zeichenfolge, die Can&apos;t interweave {0} with aspect {1}: The following aspect methods have undecidable pointcuts:\n{2} ähnelt.
        /// </summary>
        internal static string ERR_0013 {
            get {
                return ResourceManager.GetString("ERR_0013", resourceCulture);
            }
        }
        
        /// <summary>
        ///   Sucht eine lokalisierte Zeichenfolge, die The aspect-method &apos;{0}&apos; tries to introduce the private interface &apos;{1}&apos;. Introductions are only allowed for public interfaces. ähnelt.
        /// </summary>
        internal static string ERR_0014 {
            get {
                return ResourceManager.GetString("ERR_0014", resourceCulture);
            }
        }
        
        /// <summary>
        ///   Sucht eine lokalisierte Zeichenfolge, die Invalid parameter declaration in aspect method &apos;{0}&apos;: Aspect methods using the Destroy attribute are expected to be parameterless. Only Aspect parameter attributes are allowed. ähnelt.
        /// </summary>
        internal static string ERR_0015 {
            get {
                return ResourceManager.GetString("ERR_0015", resourceCulture);
            }
        }
        
        /// <summary>
        ///   Sucht eine lokalisierte Zeichenfolge, die Wrong visiblity of join-point variable &apos;{0}&apos;: The visibility change in {1} to &apos;{2}&apos; is not allowed. ähnelt.
        /// </summary>
        internal static string ERR_0016 {
            get {
                return ResourceManager.GetString("ERR_0016", resourceCulture);
            }
        }
        
        /// <summary>
        ///   Sucht eine lokalisierte Zeichenfolge, die Invalid use of the join-point variable scope &apos;Override&apos;: Cannot override non-existing target class member &apos;{0}&apos; using join-point variable &apos;{0}&apos; on aspect method {1}. ähnelt.
        /// </summary>
        internal static string ERR_0017 {
            get {
                return ResourceManager.GetString("ERR_0017", resourceCulture);
            }
        }
        
        /// <summary>
        ///   Sucht eine lokalisierte Zeichenfolge, die Inconsistent visibility of the join-point variable &apos;{0}&apos;: The scope of &apos;{0}&apos; was defined different on multiple aspect methods. Error occured at {1}. ähnelt.
        /// </summary>
        internal static string ERR_0018 {
            get {
                return ResourceManager.GetString("ERR_0018", resourceCulture);
            }
        }
        
        /// <summary>
        ///   Sucht eine lokalisierte Zeichenfolge, die Illegal combination of Scopes for join-point variable &apos;{0}&apos; at {1}. ähnelt.
        /// </summary>
        internal static string ERR_0019 {
            get {
                return ResourceManager.GetString("ERR_0019", resourceCulture);
            }
        }
        
        /// <summary>
        ///   Sucht eine lokalisierte Zeichenfolge, die Invalid type of join-point variable &apos;{0}&apos; in &apos;{1}&apos;: The expected type was &apos;{2}&apos; and was declared in &apos;{3}&apos;. ähnelt.
        /// </summary>
        internal static string ERR_0020 {
            get {
                return ResourceManager.GetString("ERR_0020", resourceCulture);
            }
        }
        
        /// <summary>
        ///   Sucht eine lokalisierte Zeichenfolge, die Invalid parameter &apos;{0}&apos; in &apos;{1}&apos;: A local join-point variable is not allowed for [Create] Advices. ähnelt.
        /// </summary>
        internal static string ERR_0021 {
            get {
                return ResourceManager.GetString("ERR_0021", resourceCulture);
            }
        }
        
        /// <summary>
        ///   Sucht eine lokalisierte Zeichenfolge, die The aspect method &apos;{0}&apos; has conflicting return type constraints. The declared return type and the aspect parameter type of [JPRetVal] have to be identical.   ähnelt.
        /// </summary>
        internal static string ERR_0022 {
            get {
                return ResourceManager.GetString("ERR_0022", resourceCulture);
            }
        }
        
        /// <summary>
        ///   Sucht eine lokalisierte Zeichenfolge, die This attribute is no longer supported. Go to the documentation for further information. ähnelt.
        /// </summary>
        internal static string ERR_0023 {
            get {
                return ResourceManager.GetString("ERR_0023", resourceCulture);
            }
        }
        
        /// <summary>
        ///   Sucht eine lokalisierte Zeichenfolge, die Aspect {0} has a invalid XML configuration: {1}. ähnelt.
        /// </summary>
        internal static string ERR_0024 {
            get {
                return ResourceManager.GetString("ERR_0024", resourceCulture);
            }
        }
        
        /// <summary>
        ///   Sucht eine lokalisierte Zeichenfolge, die Invalid configuration: Unable to resolve type &apos;{0}&apos; in assembly &apos;{1}&apos;. ähnelt.
        /// </summary>
        internal static string ERR_0025 {
            get {
                return ResourceManager.GetString("ERR_0025", resourceCulture);
            }
        }
        
        /// <summary>
        ///   Sucht eine lokalisierte Zeichenfolge, die Internal Error. ähnelt.
        /// </summary>
        internal static string ERR_9000 {
            get {
                return ResourceManager.GetString("ERR_9000", resourceCulture);
            }
        }
        
        /// <summary>
        ///   Sucht eine lokalisierte Zeichenfolge, die Invalid operation. ähnelt.
        /// </summary>
        internal static string ERR_9001 {
            get {
                return ResourceManager.GetString("ERR_9001", resourceCulture);
            }
        }
        
        /// <summary>
        ///   Sucht eine lokalisierte Zeichenfolge, die No overload of the method or constructor takes the following arguments: {0} ähnelt.
        /// </summary>
        internal static string ERR_9002 {
            get {
                return ResourceManager.GetString("ERR_9002", resourceCulture);
            }
        }
        
        /// <summary>
        ///   Sucht eine lokalisierte Zeichenfolge, die Can&apos;t invoke target method: The parameter count doesn&apos;t match. ähnelt.
        /// </summary>
        internal static string ERR_9003 {
            get {
                return ResourceManager.GetString("ERR_9003", resourceCulture);
            }
        }
        
        /// <summary>
        ///   Sucht eine lokalisierte Zeichenfolge, die User defined [Error] on join point {0}: {1} ähnelt.
        /// </summary>
        internal static string ERR_9010 {
            get {
                return ResourceManager.GetString("ERR_9010", resourceCulture);
            }
        }
    }
}
