﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace NextGenBase.Extensions
{
    public static class EnumerableExtensions
    {
        public static void ForEach<T>(this IEnumerable<T> @this, Action<T> action)
        {
            foreach (T item in @this)
            {
                action(item);
            }
        }

        /// <summary>
        /// Can be used in LINQ chain building to perform some action on each element using deferred execution.
        /// </summary>
        public static IEnumerable<T> Apply<T>(this IEnumerable<T> source, Action<T> action) where T : class
        {
            foreach (var e in source)
            {
                action(e);
                yield return e;
            }
        }

        /// <summary>
        /// <para>Starts enumeration of IEnumerable{T}.</para>
        /// <para>Performs enumeration in the fastest way because of no other actions, such as converting to list etc, are performed.</para>
        /// <para> </para>
        /// <para><remarks>Remark: This is some kind of applying changes.</remarks></para>
        /// <para> </para>
        /// <para><example>Example: <code>%IEnumerable{T}%.Where(o => o == 0).Apply(o => o += 1).Do()</code></example></para> 
        /// <para><returns><c>Returns: True</c> if at least one chained action was performed, <c>false</c> otherwise.</returns></para>       
        /// </summary>
        /// <returns><c>True</c> if at least one chained action was performed, <c>false</c> otherwise.</returns>
        public static bool Do<T>(this IEnumerable<T> source)
        {
            bool anyActionPerformed = false;
            foreach (var o in source) { anyActionPerformed = true; }
            return anyActionPerformed;
        }

        /// <summary>
        /// Returns all distinct elements of the given source, where "distinctness"
        /// is determined via a projection and the default equality comparer for the projected type.
        /// </summary>
        /// <typeparam name="TSource">Type of the source sequence</typeparam>
        /// <typeparam name="TKey">Type of the projected element</typeparam>
        /// <param name="source">Source sequence</param>
        /// <param name="keySelector">Projection for determining "distinctness"</param>
        /// <returns>A sequence consisting of distinct elements from the source sequence,
        /// comparing them by the specified key projection.</returns>
        public static IEnumerable<TSource> DistinctBy<TSource, TKey>(this IEnumerable<TSource> source, Func<TSource, TKey> keySelector)
        {
            HashSet<TKey> seenKeys = new HashSet<TKey>();
            foreach (TSource element in source)
            {
                if (seenKeys.Add(keySelector(element)))
                {
                    yield return element;
                }
            }
        }

        /// <summary>
        /// <para>Determines whether the specified source has at last more then one element.</para>
        /// <para><remarks>Using IsMultiple() is faster then Count() because this does not iterate the whole collection.</remarks></para>
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="source">The source.</param>
        /// <returns></returns>
        public static bool IsMultiple<T>(this IEnumerable<T> source)
        {
            var enumerator = source.GetEnumerator();
            return enumerator.MoveNext() && enumerator.MoveNext();
        }

        /// <summary>
        /// Gets the duplicates.
        /// </summary>
        /// <typeparam name="TSource">The type of the source.</typeparam>
        /// <typeparam name="TKey">The type of the key.</typeparam>
        /// <param name="source">The source.</param>
        /// <param name="selector">The selector.</param>
        /// <returns></returns>
        public static IEnumerable<TSource> GetDuplicates<TSource, TKey>(this IEnumerable<TSource> source, Func<TSource, TKey> selector)
        {
            var grouped = source.GroupBy(selector);
            var moreThen1 = grouped.Where(i => i.IsMultiple());
            return moreThen1.SelectMany(i => i);
        }

        /// <summary>
        /// Gets the duplicates.
        /// </summary>
        /// <typeparam name="TSource">The type of the source.</typeparam>
        /// <typeparam name="TKey">The type of the key.</typeparam>
        /// <param name="source">The source.</param>
        /// <returns></returns>
        public static IEnumerable<TSource> GetDuplicates<TSource>(this IEnumerable<TSource> source)
        {
            return source.GetDuplicates(i => i);
        }        

        /// <summary>
        /// Filters source ignoring specified element
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="source">The source.</param>
        /// <param name="element">The element.</param>
        /// <returns></returns>
        public static IEnumerable<T> Except<T>(this IEnumerable<T> source, T element)
        {
            return source.Where(o => !o.Equals(element));
        }
    }
}
