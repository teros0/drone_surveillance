fastJSON
========

Smallest, fastest polymorphic JSON serializer

see the article here : [http://www.codeproject.com/Articles/159450/fastJSON] (http://www.codeproject.com/Articles/159450/fastJSON)
