﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using jetMapper;
using jetMapper.Extensions;
using NextGenBase.Attributes.Routing;
using NextGenBase.Extensions;
using NextGenBase.Helpers;
using NextGenBase.Interfaces;

namespace NextGenBase
{
    public abstract partial class CRUDProvider<T, TEntity> : IRESTPatch
    {
         #region Patch

        [System.Web.Http.AcceptVerbs("PATCH")]
        [Route("ChangeMultipleAction", typeof (IRESTPatch), "/{controller}")]
        public Task<HttpResponseMessage> ChangeMultipleAction(HttpRequestMessage request)
        {
            var content = request.Content.ReadAsStringAsync()
                .ContinueWith(task => 
                    Parser.ToEnumerable<Dictionary<string, object>>(task.Result));

            return ValidateAndInvokeAsync(request, 
                async (ActionContainer<IEnumerable<T>> container) =>
            {
                try
                {                
                    var results = new List<TEntity>();
                    var idName = DataService.GetIdName(null);
                    foreach (var d in await content)
                    {
                        var entity = DataProvider.Find(d[idName]);                    
                        var obj = DataService.Map<TEntity, T>(entity).Proxy();

                        var changes = d;

                        //if (changes == null) throw new ArgumentNullException("changes");

                        var newObj = obj.Fill(new T());

                        foreach (var o in changes.Where(o => obj.Contains(o.Key)))
                        {
                            newObj[o.Key] = o.Value;
                        }

                        var validationResult = _patch(newObj);
                        if (validationResult.Success)
                        {
                            var entityProxy = Mapper.Create<TEntity, T>().GenerateProxy(entity);
                            results.Add(entityProxy.UnderlyingObject);                        
                            foreach (var o in changes.Where(o => obj.Contains(o.Key) && !idName.Equals(o.Key)))
                            {
                                entityProxy[o.Key] = o.Value;
                            }                                             
                        }
                        else
                        {
                            Repository.Rollback();
                            container.AddError(
                                new InvalidOperationException("Action cannot be performed due to error!",
                                    new AggregateException(validationResult.Errors.Select(error => new Exception(error)))));
                            return null;
                        }
                    }

                    Repository.SaveChanges();

                    return results.Select(o => DataService.Map<TEntity, T>(o));
                }
                catch (Exception e)
                {
                    Repository.Rollback();
                    container.AddError(e);
                    return null;
                }
            },
                HttpStatusCode.OK,
                Repository.Rollback,
                InterfaceTypes[Interface.Patch]);
        }

        [System.Web.Http.AcceptVerbs("PATCH")]
        [Route("ChangeAction", typeof (IRESTPatch), "/{controller}/{id}/")]
        public Task<HttpResponseMessage> ChangeAction(HttpRequestMessage request, int id)
        {
            var content = request.Content.ReadAsAsync<Dictionary<string, object>>();
            var idName = DataService.GetIdName(null);

            return ValidateAndInvokeAsync(request, 
                async (ActionContainer<T> container) =>
            {
                var entity = DataProvider.Find(id);                
                var obj = DataService.Map<TEntity, T>(entity).Proxy();

                var changes = await content;

                if (changes == null)
                {
                    container.AddError(new ArgumentNullException("changes"));
                    return null;
                }

                var newObj = obj.Fill(new T());

                foreach (var o in changes.Where(o => obj.Contains(o.Key)))
                {
                    newObj[o.Key] = o.Value;
                }

                var validationResult = _patch(newObj);
                if (validationResult.Success)
                {
                    var entityProxy = Mapper.Create<TEntity, T>().GenerateProxy(entity);

                    foreach (var o in changes.Where(o => obj.Contains(o.Key) && !idName.Equals(o.Key)))
                    {
                        entityProxy[o.Key] = o.Value;
                    }

                    Repository.SaveChanges();

                    return newObj.Raw;
                }
                else
                {
                    Repository.Rollback();
                    container.AddError(
                        new InvalidOperationException("Action cannot be performed due to error!",
                            new AggregateException(validationResult.Errors.Select(error => new Exception(error)))));
                    return null;
                }                
            },
                HttpStatusCode.OK,
                Repository.Rollback,
                InterfaceTypes[Interface.Patch]);
        }

        private ActionContainer<T> _patch(T obj)
        {
            return _chainInvoker(InterfaceTypes[Interface.Patch], new ActionContainer<T> {Value = obj})
                .Apply(o => ControllerMetadatas[GetType()].CustomeServicesChain[InterfaceTypes[Interface.Get]](o));
        }

        #endregion 
    }
}