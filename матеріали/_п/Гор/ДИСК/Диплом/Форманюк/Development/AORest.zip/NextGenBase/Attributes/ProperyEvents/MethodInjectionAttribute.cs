﻿using System;

namespace NextGenBase.Attributes.ProperyEvents
{
    public class MethodInjectionAttribute : Attribute
    {
        public Type Interface { get; private set; }        

        public MethodInjectionAttribute(Type @interface)
        {
            Interface = @interface;            
        }
    }
}