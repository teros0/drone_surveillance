﻿using System.Collections.Generic;

namespace NextGenBase.Interfaces
{
    internal interface IRawDataProvider
    {
        Dictionary<string, object> RawData { get; } 
    }
}