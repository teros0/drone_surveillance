﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using jetREST.Mapper.Extensions;
using jetREST.Mapper.Helpers;
using NextGenBase.Helpers;

namespace jetREST.Mapper
{    
    internal class PropertyMap<TSource, TDestination>
    {
        public DataProxy<TSource> Source { get; set; }
        public DataProxy<TDestination> Destination { get; set; }
        public List<EditableKeyValuePair<string, string>> AdditionalMaps { get; set; }
    }

    public class Mapper
    {        
        public static readonly Dictionary<ArgArray, object> _maps
            = new Dictionary<ArgArray, object>();
        protected static readonly Lazy<Dictionary<string, Delegate>> _globalMethods =
            new Lazy<Dictionary<string, Delegate>>();
    }

    public class Mapper<TSource, TDestination> : Mapper
        where TDestination : new()
    {        
        private ArgArray _args;
        private Type _source;
        private Type _destination;
        private PropertyMap<TSource, TDestination> _map;

        public static Mapper<TSource, TDestination> Map()
        {
            var mapper = new Mapper<TSource, TDestination>();
            var s = mapper._source = typeof(TSource);
            var t = mapper._destination = typeof(TDestination);
            var args = mapper._args = new ArgArray(s, t);
            if (!Mapper._maps.ContainsKey(args))
            {
                var destination = new DataProxy<TDestination>();
                var source = new DataProxy<TSource>();
                mapper._map = new PropertyMap<TSource, TDestination>
                {
                    Destination  = destination,
                    Source = source,
                    AdditionalMaps = new List<EditableKeyValuePair<string, string>>()
                };

                Mapper._maps.Add(args, mapper._map);
            }
            else
            {
                mapper._map = (PropertyMap<TSource, TDestination>)Mapper._maps[args];   
            }

            return mapper;
        }

        public Mapper<TSource, TDestination> Remap(string source, string destination)
        {
            lock (this)
            {
                if (!_map.AdditionalMaps.Any(o => o.Key.Equals(destination)))
                {
                    _map.AdditionalMaps.Add(new EditableKeyValuePair<string, string>(destination, source));
                }
                else
                {
                    _map.AdditionalMaps.Single(o => o.Key.Equals(destination)).Value = source;
                }
            }
            return this;
        }

        public Mapper<TSource, TDestination> RegisterSourceMethod<T>(string name, T method)
        {
            _map.Source.RegisterMethod(name, method);
            return this;
        }

        public Mapper<TSource, TDestination> RegisterDestinationMethod<T>(string name, T method)
        {
            _map.Destination.RegisterMethod(name, method);
            return this;
        }

        public Mapper<TSource, TDestination> RegisterMethod<T>(string name, T method)
        {
            _map.Source.RegisterMethod(name, method);
            _map.Destination.RegisterMethod(name, method);
            return this;
        }

        public Mapper<TSource, TDestination> RegisterGlobalMethod<T>(string name, T method)
        {
            if (!_globalMethods.Value.ContainsKey(name))
            _globalMethods.Value.Add(name, method.As<Delegate>());
            return this;
        }

        public TDestination Do(TSource obj)
        {
            var additionalMaps = _map.AdditionalMaps.ToList();
            var dest = new TDestination();
            foreach (var o in ((PropertyMap<TSource, TDestination>)Mapper._maps[_args]).Destination)
            {
                if (!additionalMaps.Any(k => k.Key.Contains(o)))
                {
                    var val = _map.Source[obj, o];
                    _map.Destination[dest, o] = val is string ? ((string)val).Trim() : val;
                }
                else
                {
                    var map = additionalMaps.First(m => m.Value.EndsWith(o) || m.Key.StartsWith(o));
                    additionalMaps.Remove(map);

                    string sourcePath = map.Value;
                    string destinationPath = map.Key;

                    var sourceValue = _getSourceValue(sourcePath, obj.As<TSource>()).Result;

                    string prop;
                    var targetObj = _getDestinationValue(destinationPath, dest, out prop);
                    if(destinationPath.Split('/').IsMultiple())
                        DataProxy.Create(targetObj)[prop] = sourceValue;
                    else
                        DataProxy.Create((TDestination)targetObj)[prop] = sourceValue;
                }
            }

            return dest;
        }

        public async Task<TDestination> DoAsync(TSource obj)
        {
            var additionalMaps = _map.AdditionalMaps.ToList();
            var dest = new TDestination();
            foreach (var o in ((PropertyMap<TSource, TDestination>)Mapper._maps[_args]).Destination)
            {
                if (!additionalMaps.Any(k => k.Key.Contains(o)))
                {
                    var val = _map.Source[obj, o];
                    _map.Destination[dest, o] = val is string ? ((string)val).Trim() : val;
                }
                else
                {
                    var map = additionalMaps.First(m => m.Value.EndsWith(o) || m.Key.StartsWith(o));
                    additionalMaps.Remove(map);

                    string sourcePath = map.Value;
                    string destinationPath = map.Key;

                    var sourceValue = _getSourceValue(sourcePath, obj);

                    string prop;
                    var targetObj = _getDestinationValue(destinationPath, dest, out prop);
                    if (destinationPath.Split('/').IsMultiple())
                        DataProxy.Create(targetObj)[prop] = await sourceValue;
                    else
                        DataProxy.Create((TDestination)targetObj)[prop] = await sourceValue;
                }
            }

            return dest;
        }

        private Task<object> _getSourceValue<T>(string path, T obj)
        {
            var paths = path.Split('/').Select(x => x.Trim()).ToArray();

            if (!paths.IsMultiple()) return Task.FromResult(DataProxy.Create(obj)[paths.First()]);

            return Task.Run(() => 
            {
                object tempValue = obj;  
                var firstPath = paths.First();
                var xx = DataProxy.Create(obj);
                if (xx.ContainsProperty(firstPath))
                {
                    var result = xx[firstPath];
                    var func = result as Func<object>;
                    tempValue = func != null ? func() : result;
                }
                else if (xx.ContainsMethod(firstPath))
                {
                    tempValue = xx.Methods[firstPath].As<Func<object>>()();
                }
                else if (_globalMethods.Value.ContainsKey(firstPath))
                {
                    tempValue = _globalMethods.Value[firstPath].DynamicInvoke(tempValue);
                }
                          
                foreach (var s in paths.Skip(1))
                {
                    var x = DataProxy.Create(tempValue);
                    if (x.ContainsProperty(s))
                    {
                        var result = x[s];
                        var func = result as Func<object>;
                        tempValue = func != null ? func() : result;
                    }
                    else if (x.ContainsMethod(s))
                    {
                        tempValue = x.Methods[s].As<Func<object>>()();
                    }
                    else if (_globalMethods.Value.ContainsKey(s))
                    {
                        tempValue = _globalMethods.Value[s].DynamicInvoke(tempValue);
                    }
                }

                return tempValue;
            });
        }

        private object _getDestinationValue<T>(string path, T obj, out string propertyName)
        {
            var paths = path.Split('/').Select(x => x.Trim()).ToList();
            propertyName = paths.Last();
            paths.Remove(propertyName);

            if (!paths.Any()) return obj;
            if (!paths.IsMultiple()) return DataProxy.Create(obj)[paths.First()];

            object tempValue = obj;

            var cc = DataProxy.Create(obj);

            string firstPath = paths.First();

            if (cc.ContainsProperty(firstPath))
            {
                tempValue = cc[firstPath];
            }
            else if (cc.ContainsMethod(firstPath))
            {
                tempValue = cc.Methods[firstPath].As<Func<object>>();
            }
            else if (_globalMethods.Value.ContainsKey(firstPath))
            {
                tempValue = _globalMethods.Value[firstPath].DynamicInvoke(tempValue);
            }       

            foreach (var s in paths.Skip(1))
            {
                var c = DataProxy.Create(tempValue);
                if (c.ContainsProperty(s))
                {
                    tempValue = c[s];
                }
                else if (c.ContainsMethod(s))
                {
                    tempValue = c.Methods[s].As<Func<object>>();
                }
                else if (_globalMethods.Value.ContainsKey(s))
                {
                    tempValue = _globalMethods.Value[s].DynamicInvoke(tempValue);
                }
            }

            return tempValue;
        }       
    }
}
