﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using jetMapper;
using jetMapper.Extensions;
using NextGenBase.Attributes.Routing;
using NextGenBase.Extensions;
using NextGenBase.Helpers;
using NextGenBase.Interfaces;

namespace NextGenBase
{
    public abstract partial class CRUDProvider<T, TEntity>
    {
         #region Put

        [System.Web.Http.HttpPut]
        [Route("FullChangeAction", typeof (IRESTPut<>), "/{controller}/{id}/")]
        public Task<HttpResponseMessage> FullChangeAction(HttpRequestMessage request, int id)
        {
            var content = request.Content.ReadAsAsync<T>();

            return ValidateAndInvokeAsync(request, async (ActionContainer<T> container) =>
            {
                var obj = await content;

                var validationResult = _put(obj);
                if (validationResult.Success)
                {
                    var entity = Mapper.Create<TEntity, T>()
                        .GenerateProxy(GetEntity(id));

                    var objProxy = obj.Proxy();

                    objProxy.ForEach(x => entity[x] = objProxy[x]);

                    Repository.SaveChanges();

                    return DataService.Map<TEntity, T>(entity.UnderlyingObject);
                }
                else
                {
                    Repository.Rollback();
                    container.AddError(
                        new InvalidOperationException(
                            "Action cannot be performed due to error!",
                            new AggregateException(validationResult.Errors.Select(error => new Exception(error)))));
                    return null;
                }               
            }, 
            HttpStatusCode.OK, 
            Repository.Rollback, 
            InterfaceTypes[Interface.Put]);
        }

        [System.Web.Http.HttpPut]
        [Route("FullChangeAction", typeof(IRESTPut<>), "/{controller}")]
        public Task<HttpResponseMessage> FullMultipleChangeAction(HttpRequestMessage request)
        {
            var content = request.Content.ReadAsStringAsync()
                .ContinueWith(task => 
                    Parser.ToEnumerable<T>(task.Result));

            var results = new List<TEntity>();

            return ValidateAndInvokeAsync(request, async (ActionContainer<IEnumerable<T>> container) =>
            {
                var objEnumerable = await content;
                foreach (var obj in objEnumerable)
                {
                    var validationResult = _put(obj);
                    if (validationResult.Success)
                    {
                        var entity = Mapper.Create<TEntity, T>()
                            .GenerateProxy(GetEntity(DataService.GetId(obj)));

                        var objProxy = obj.Proxy();

                        objProxy.ForEach(x => entity[x] = objProxy[x]);
                        results.Add(entity.UnderlyingObject);
                    }
                    else
                    {
                        Repository.Rollback();
                        container.AddError(
                            new InvalidOperationException(
                                "Action cannot be performed due to error!",
                                new AggregateException(validationResult.Errors.Select(error => new Exception(error)))));
                        return null;
                    }  
                }                

                Repository.SaveChanges();
                
                return results.Select(o => DataService.Map<TEntity, T>(o));
            },
            HttpStatusCode.OK,
            Repository.Rollback,
            InterfaceTypes[Interface.Put]);
        }

        private ActionContainer<T> _put(T obj)
        {            
            return _chainInvoker<ActionContainer<T>>(typeof(IRESTPut<T>), obj)
                .Apply(o => ControllerMetadatas[GetType()].CustomeServicesChain[InterfaceTypes[Interface.Get]](o));
        }

        #endregion 
    }
}