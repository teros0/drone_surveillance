﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using jetREST.Mapper;
using jetREST.Mapper.Extensions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using WebApplication.Models;

namespace jetREST.Mapper.Tests
{
    [TestClass()]
    public class MapperTests
    {
        [TestMethod()]
        public void DoTest()
        {
            Func<IList<Test2Data>, Test2Data> indexerGet = list => list.First();
            Func<IList<Test2Data>, Test2Data> indexerSet = list => list.Apply(o => o.Add(new Test2Data())).Last();

            Mapper<TestData, TestDataModel>.Map()
                .RegisterSourceMethod("indexerGet", indexerGet)
                .RegisterDestinationMethod("indexerSet", indexerSet);

            Mapper<TestData, TestDataModel>.Map()
                .Remap("Test2Data/indexerGet/Value3", "Value3")
                .Remap("Test2Data/indexerGet/Value4", "Value4");

            Mapper<TestDataModel, TestData>.Map()
                .Remap("Value3", "Test2Data/indexerSet/Value3")
                .Remap("Value4", "Test2Data/indexerSet/Value4");
        }
    }
}
