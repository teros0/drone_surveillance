﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using jetMapper.Extensions;
using NextGenBase.Extensions;
using NextGenBase.Factories;

namespace NextGenBase.Queue
{
    public abstract partial class QueueProvider<T, TResult, TQResult, TConcreteType> 
        where T: class
    {
        public event Action<T> QueueUpdated;
        public event Action<QueueProvider<T, TResult, TQResult, TConcreteType>> ExecutionStarted;
        public event Action<QueueProvider<T, TResult, TQResult, TConcreteType>> ExecutionFinished;
        public event Action<QueueProvider<T, TResult, TQResult, TConcreteType>> ExecutionCanceled;

        public Task<TQResult> QWorker { get; private set; }
        protected ConcurrentQueue<Func<T, TResult>> Queue {get; private set;}
        public T Tag { get; private set; }
        public State WorkerState { get; private set; }
        public object Lock { get; protected set; }
        public CancellationToken CancellationToken { get; private set; }
        protected CancellationTokenSource TokenSource;

        protected object[] QueueProsessingArgs { get; set; }

        public static TConcreteType Factory(T obj, params object[] args)
        {
            string factoryKey = obj.GetType().Name;//(obj.GetHashCode() + typeof(TConcreteType).FullName).ToString();
            GenericFactory<TConcreteType>.Instance
                .Register(factoryKey, objects => typeof(TConcreteType).Construct<TConcreteType>(obj, args), @override: false);
            return GenericFactory<TConcreteType>.Instance.Create(factoryKey);
        }

        /// <summary>
        /// Remark: Factory method with parameter is more recommended
        /// </summary>
        /// <returns></returns>
        public static TConcreteType Factory()
        {
            string factoryKey = typeof(TConcreteType).Name;
            GenericFactory<TConcreteType>.Instance
                .Register(factoryKey, objects => typeof(TConcreteType).Construct<TConcreteType>(default(T), null), @override: false);
            return GenericFactory<TConcreteType>.Instance.Create(factoryKey);
        }

        protected QueueProvider(T obj, params object[] args)
        {            
            Tag = obj;
            TokenSource = new CancellationTokenSource();
            ExecutionStarted += provider => WorkerState = State.Busy;
            ExecutionFinished += provider => WorkerState = State.Ready;
            ExecutionCanceled += provider => WorkerState = State.Ready;
            QueueProsessingArgs = args;
        }        

        public void Add(Func<T, TResult> action, bool autoStart = false)
        {
            Queue.Enqueue(action);
            if (QueueUpdated != null) QueueUpdated(Tag);
            if (WorkerState != State.Busy && autoStart)
            {
                Start();            
            }                      
        }

        public void Start()
        {
            QWorker.Dispose();

            TokenSource = new CancellationTokenSource();
            CancellationToken = TokenSource.Token;

            QWorker = Task.Factory.StartNew(() => QueueProsessing(QueueProsessingArgs), CancellationToken); 
        }

        public void Cancel()
        {
            TokenSource.Cancel();
            TokenSource.Dispose();
            ExecutionCanceled(this);
        }
       
        protected abstract TQResult QueueProsessing(params object[] args);

        public static QueueProvider<T, TResult, TQResult, TConcreteType> operator 
            +(QueueProvider<T, TResult, TQResult, TConcreteType> provider, Func<T, TResult> action)
        {
            return provider
                .Apply(o => o.Add(action));
        }

        public enum State
        {
            Busy = 1,
            Ready = 2
        }
    }
}
