﻿using System;
using System.Collections.Generic;
using System.Linq;
using CommonV2.EventArgs;
using CommonV2.Extensions;
using CommonV2.Helpers;

namespace CommonV2.Collections
{
    /// <summary>
    /// Provides generic key-related observable container with duplications resolver
    /// </summary>
    public sealed class ObservableDynamicContainer<T> : CObservableContainer<T>
    {
        #region Members

        private Dictionary<int, ReferenceCounter<T>> m_innereReferenceCounter;

        #endregion

        #region ctors

        /// <summary>
        /// Initializes a new instance of the <see cref="CObservableDynamicContainer{T}"/> class.
        /// </summary>
        public ObservableDynamicContainer()
            : base()
        {
            m_innereReferenceCounter = new Dictionary<int, ReferenceCounter<T>>();
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CObservableDynamicContainer{T}"/> class.
        /// </summary>
        /// <param name="key">The key.</param>
        /// <param name="array">The array.</param>
        public ObservableDynamicContainer(int key, IEnumerable<T> array)
            : base(key, array)
        {
            m_innereReferenceCounter.Add(key, new ReferenceCounter<T>());
            array.ForEach(item => m_innereReferenceCounter[key].Add(item));
        }

        #endregion

        #region Events

        /// <summary>
        /// Occurs on element change
        /// </summary>
        public override event EventHandler<NotificationChangeEventArgs<T>> OnChange;

        #endregion

        #region Indexers

        public override T this[int key, T item]
        {
            get { return base[key, item]; }
            set
            {
                if (!Contains(key)) throw ThrowArgumentException(key);

                var targetCollection = m_innerCollection[key];
                int newValueRefCount = m_innereReferenceCounter[key].Add(value);
                int oldValueRefCount = m_innereReferenceCounter[key].Remove(item);
                if (newValueRefCount == 1 && oldValueRefCount == 0)
                {
                    OnChange(this, new NotificationChangeEventArgs<T>(key, item, value));
                    m_innerCollection[key][targetCollection.IndexOf(item)] = value;
                }
                else if (newValueRefCount > 1 && oldValueRefCount == 0)
                {
                    base.Remove(key, item);
                }
                else if (newValueRefCount == 1)
                {
                    base.Add(key, value);
                }
            }
        }

        #endregion

        #region Add methods

        /// <summary>
        /// Adds the specified item related to key.
        /// </summary>
        /// <param name="key">The key.</param>
        /// <param name="item">The item.</param>
        public override void Add(int key)
        {
            if (Contains(key))
            {
                this.Clear(key);
            }
            else
            {
                InitKey(key);
            }
        }

        /// <summary>
        /// Adds the specified item related to key.
        /// </summary>
        /// <param name="key">The key.</param>
        /// <param name="item">The item.</param>
        public override void Add(int key, T item)
        {
            if (!Contains(key)) m_innereReferenceCounter.Add(key, new ReferenceCounter<T>());

            if (m_innereReferenceCounter[key].Add(item) == 1)
                base.Add(key, item);
        }

        /// <summary>
        /// Adds the range.
        /// </summary>
        /// <param name="key">The key.</param>
        /// <param name="items">The items.</param>
        public override void AddRange(int key, IEnumerable<T> items)
        {
            if (!Contains(key)) m_innereReferenceCounter.Add(key, new ReferenceCounter<T>());

            var newItems = items.Where(o => m_innereReferenceCounter[key].Add(o) == 1);
            base.AddRange(key, newItems);
        }

        /// <summary>
        /// Inserts the specified item for key.
        /// </summary>
        /// <param name="key">The key.</param>
        /// <param name="index">The index.</param>
        /// <param name="item">The item.</param>
        public override void Insert(int key, int index, T item)
        {
            if (!Contains(key)) m_innereReferenceCounter.Add(key, new ReferenceCounter<T>());

            if (m_innereReferenceCounter[key].Add(item) == 1)
                base.Insert(key, index, item);
        }

        #endregion

        #region Remove methods

        /// <summary>
        /// Removes the specified item from key.
        /// </summary>
        /// <param name="key">The key.</param>
        /// <param name="item">The item.</param>
        /// <returns></returns>
        public override bool Remove(int key, T item)
        {
            if (!Contains(key)) throw ThrowArgumentException(key);

            if (m_innereReferenceCounter[key].Remove(item) == 0)
                return base.Remove(key, item);
            return false;
        }

        /// <summary>
        /// Removes item at specified index from key.
        /// </summary>
        /// <param name="key">The key.</param>
        /// <param name="index">The index.</param>
        public override void RemoveAt(int key, int index)
        {
            if (!Contains(key)) throw ThrowArgumentException(key);

            T item = m_innerCollection[key].ElementAt(index);
            if (m_innereReferenceCounter[key].Remove(item) == 0)
                base.RemoveAt(key, index);
        }

        /// <summary>
        /// Removes the range.
        /// </summary>
        /// <param name="key">The key.</param>
        /// <param name="items">The items.</param>
        public override void RemoveRange(int key, IEnumerable<T> items)
        {
            if (!Contains(key)) throw ThrowArgumentException(key);

            var itemsToRemove = items.Where(o => m_innereReferenceCounter[key].Remove(o) == 0);
            base.RemoveRange(key, itemsToRemove);
        }

        /// <summary>
        /// Removes the range.
        /// </summary>
        /// <param name="key">The key.</param>
        /// <param name="index">The index.</param>
        /// <param name="count">The count.</param>
        public override void RemoveRange(int key, int index, int count)
        {
            if (!Contains(key)) throw ThrowArgumentException(key);

            var itemsToRemove = m_innerCollection[key].GetRange(index, count);
            this.RemoveRange(key, itemsToRemove);
        }

        #endregion

        #region Clear

        /// <summary>
        /// Clears the items related to key
        /// </summary>
        /// <param name="key">The key.</param>
        public override void Clear(int key)
        {
            if (!Contains(key)) return;

            m_innereReferenceCounter[key].Clear();
            base.Clear(key);
        }

        #endregion

        #region Helpers

        private void InitKey(int key)
        {
            m_innereReferenceCounter.Add(key, new ReferenceCounter<T>());
            m_innerCollection.Add(key, new List<T>());
        }

        #endregion
    }
}
