﻿using System.Net.Http.Formatting;

namespace NextGenBase.Interfaces.Servises
{
    public interface IDataPresentationService : IService
    {
        MediaTypeFormatter MediaTypeFormatter { get; }
        object Result<T>(T obj);        
    }
}