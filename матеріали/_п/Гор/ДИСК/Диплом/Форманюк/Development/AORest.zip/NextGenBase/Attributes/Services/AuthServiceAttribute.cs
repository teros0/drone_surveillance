﻿using System;
using NextGenBase.Interfaces;
using NextGenBase.Interfaces.Servises;

namespace NextGenBase.Attributes.Services
{
    [AttributeUsage(AttributeTargets.Class, AllowMultiple = true, Inherited = true)]
    public class AuthServiceAttribute : ServiceAttribute
    {
        public AuthServiceAttribute(Type service) : 
            base(typeof(IAuthService), service)
        {
        }
    }
}