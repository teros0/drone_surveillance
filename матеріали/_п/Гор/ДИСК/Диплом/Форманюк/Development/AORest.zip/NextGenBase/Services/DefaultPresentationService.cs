﻿using System;
using System.Net.Http.Formatting;
using NextGenBase.Helpers;
using NextGenBase.Interfaces;
using NextGenBase.Interfaces.Servises;

namespace NextGenBase.Services
{
    public class DefaultPresentationService : IDataPresentationService
    {
        public MediaTypeFormatter MediaTypeFormatter
        {
            get { return new JsonMediaTypeFormatter(); }
        }

        public object Result<T>(T obj)
        {
            return obj;
        }

        public ActionContainer Invoke(ActionContainer container)
        {
            throw new System.NotImplementedException();
        }

        void IDisposable.Dispose()
        {

        }

        public object Environment
        {
            get;
            set;
        }
    }
}