﻿using System;
using System.Reflection;

namespace jetREST.Mapper
{
    internal class AccessObject<T, TResult>
    {
        public PropertyInfo PropertyInfo { get; set; }
        public Func<T, TResult> Get { get; set; }
        public Action<T, TResult> Set { get; set; }
    }
}
