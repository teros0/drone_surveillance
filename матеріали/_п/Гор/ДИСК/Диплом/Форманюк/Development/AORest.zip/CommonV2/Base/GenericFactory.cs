﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using CommonV2.Extensions;
using CommonV2.Interfaces;

namespace CommonV2.Base
{
    public class GenericFactory<T> : ASingleton<GenericFactory<T>>, IGenericFactory<T>
    {
        private readonly Dictionary<object, Func<object[], T>> _dict;

        protected GenericFactory()
        {
            _dict = new Dictionary<object, Func<object[], T>>();
            OnGettingInstance += () =>
            {
                if (!_dict.ContainsKey(typeof(T).Name))
                {
                    Register((value) => (T)typeof(T).Construct());
                }
            };
        }         

        /// <summary>
        /// Creates the specified identifier.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        /// <exception cref="System.ArgumentException">No type registered for this id</exception>
        public T Create(object id, object[] parameters = null)
        {
            Func<object[], T> constructor = null;
            if (_dict.TryGetValue(id, out constructor))
                return constructor(parameters);

            throw new ArgumentException("No type registered for this id");
        }

        public void Register(object id, Func<object[], T> ctor)
        {
            Register(id, ctor, true);
        }

        /// <summary>
        /// Creates this instance.
        /// </summary>
        /// <returns></returns>
        public T Create(object[] parameters = null)
        {
            return Create(typeof(T).Name, parameters);
        }

        public T Create()
        {
            return Create(typeof(T));
        }

        /// <summary>
        /// Creates specified identifier asynchronously.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public Task<T> CreateAsync(object id, object[] parameters = null)
        {
            return Task.Run(() => Create(id, parameters));
        }

        /// <summary>
        /// Creates specified identifier asynchronously.
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public Task<T> CreateAsync(object[] parameters)
        {
            return Task.Run(() => Create(parameters));
        }

        /// <summary>
        /// Creates specified identifier asynchronously.
        /// </summary>
        /// <returns></returns>
        public Task<T> CreateAsync()
        {
            return Task.Run(() => Create());
        }

        /// <summary>
        /// Registers the specified identifier.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <param name="ctor">The ctor.</param>
        /// <param name="override"></param>        
        public void Register(object id, Func<object[], T> ctor, bool @override)
        {
            if (_dict.ContainsKey(id))
            {
                if (@override) _dict[id] = ctor;
            }
            else
                _dict.Add(id, ctor);
        }

        /// <summary>
        /// Registers the specified ctor.
        /// </summary>
        /// <remarks>Do not overrider existing one</remarks>
        /// <param name="ctor">The ctor.</param>
        public void Register(Func<object[], T> ctor)
        {
            object id = typeof(T);            
            Register(id, ctor);
        }
    }
}
