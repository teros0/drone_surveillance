﻿using jetMapper;

namespace NextGenBase.Interfaces.Servises
{
    public interface IDataService : IEntity, IService
    {        
        TDestination Map<TSource, TDestination>(TSource entity) where TDestination : new();
        //TDestination Map<TSource, TDestination>(TSource data) where TDestination : new();
    }

    public interface IDataService<TData, TEntity> : IEntity<TEntity>, IDataService
    {
        TData DataAdapter(TEntity entity);
        TEntity EntityAdapter(TData data);        
    }

    public interface IDataServiceProvider : IServiceProvider
    {
        IDataService DataService { get; }
    }

    public interface IDataServiceProvider<TData, TEntity> : IDataServiceProvider
    {
        IDataService<TData, TEntity> DataService { get; }
    }  
}