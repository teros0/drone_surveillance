﻿// ----------------------------------------------------------------
// * The LOOM.NET project http://rapier-loom.net *
// (C) Copyright by Wolfgang Schult. All rights reserved. 
// This code is licensed under the Apache License 2.0
// To get more information, go to http://loom.codeplex.com/license
// ----------------------------------------------------------------

namespace Loom.Resources {
    using System;
    
    
    /// <summary>
    ///   Eine stark typisierte Ressourcenklasse zum Suchen von lokalisierten Zeichenfolgen usw.
    /// </summary>
    // Diese Klasse wurde von der StronglyTypedResourceBuilder automatisch generiert
    // -Klasse über ein Tool wie ResGen oder Visual Studio automatisch generiert.
    // Um einen Member hinzuzufügen oder zu entfernen, bearbeiten Sie die .ResX-Datei und führen dann ResGen
    // mit der /str-Option erneut aus, oder Sie erstellen Ihr VS-Projekt neu.
    [global::System.CodeDom.Compiler.GeneratedCodeAttribute("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0")]
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
    [global::System.Runtime.CompilerServices.CompilerGeneratedAttribute()]
    internal class CodeBuilderErrors {
        
        private static global::System.Resources.ResourceManager resourceMan;
        
        private static global::System.Globalization.CultureInfo resourceCulture;
        
        [global::System.Diagnostics.CodeAnalysis.SuppressMessageAttribute("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        internal CodeBuilderErrors() {
        }
        
        /// <summary>
        ///   Gibt die zwischengespeicherte ResourceManager-Instanz zurück, die von dieser Klasse verwendet wird.
        /// </summary>
        [global::System.ComponentModel.EditorBrowsableAttribute(global::System.ComponentModel.EditorBrowsableState.Advanced)]
        internal static global::System.Resources.ResourceManager ResourceManager {
            get {
                if (object.ReferenceEquals(resourceMan, null)) {
                    global::System.Resources.ResourceManager temp = new global::System.Resources.ResourceManager("Loom.Resources.CodeBuilderErrors", typeof(CodeBuilderErrors).Assembly);
                    resourceMan = temp;
                }
                return resourceMan;
            }
        }
        
        /// <summary>
        ///   Überschreibt die CurrentUICulture-Eigenschaft des aktuellen Threads für alle
        ///   Ressourcenzuordnungen, die diese stark typisierte Ressourcenklasse verwenden.
        /// </summary>
        [global::System.ComponentModel.EditorBrowsableAttribute(global::System.ComponentModel.EditorBrowsableState.Advanced)]
        internal static global::System.Globalization.CultureInfo Culture {
            get {
                return resourceCulture;
            }
            set {
                resourceCulture = value;
            }
        }
        
        /// <summary>
        ///   Sucht eine lokalisierte Zeichenfolge, die Can&apos;t instantiate &apos;{0}&apos;: The type must be a class. ähnelt.
        /// </summary>
        internal static string ERR_1001 {
            get {
                return ResourceManager.GetString("ERR_1001", resourceCulture);
            }
        }
        
        /// <summary>
        ///   Sucht eine lokalisierte Zeichenfolge, die Can&apos;t interweave &apos;{0}&apos; to &apos;{1}&apos;: There is already a Advice.Around method defined. ähnelt.
        /// </summary>
        internal static string ERR_1002 {
            get {
                return ResourceManager.GetString("ERR_1002", resourceCulture);
            }
        }
        
        /// <summary>
        ///   Sucht eine lokalisierte Zeichenfolge, die Can&apos;t introduce &apos;{0}&apos; due to its visibility. ähnelt.
        /// </summary>
        internal static string ERR_1003 {
            get {
                return ResourceManager.GetString("ERR_1003", resourceCulture);
            }
        }
        
        /// <summary>
        ///   Sucht eine lokalisierte Zeichenfolge, die Can&apos;t interweave &apos;{0}&apos;: There is already an introduction for &apos;{1}&apos; defined. ähnelt.
        /// </summary>
        internal static string ERR_1004 {
            get {
                return ResourceManager.GetString("ERR_1004", resourceCulture);
            }
        }
        
        /// <summary>
        ///   Sucht eine lokalisierte Zeichenfolge, die Can&apos;t interweave &apos;{0}&apos;: There is no introduction defined for &apos;{1}&apos;. ähnelt.
        /// </summary>
        internal static string ERR_1005 {
            get {
                return ResourceManager.GetString("ERR_1005", resourceCulture);
            }
        }
        
        /// <summary>
        ///   Sucht eine lokalisierte Zeichenfolge, die Can&apos;t create an instance of the abstract class &apos;{0}&apos;. ähnelt.
        /// </summary>
        internal static string ERR_1006 {
            get {
                return ResourceManager.GetString("ERR_1006", resourceCulture);
            }
        }
        
        /// <summary>
        ///   Sucht eine lokalisierte Zeichenfolge, die Can&apos;t interweave sealed class &apos;{0}&apos;. ähnelt.
        /// </summary>
        internal static string ERR_1007 {
            get {
                return ResourceManager.GetString("ERR_1007", resourceCulture);
            }
        }
        
        /// <summary>
        ///   Sucht eine lokalisierte Zeichenfolge, die Can&apos;t interweave &apos;{0}&apos;: The generic parameter &apos;{1}&apos; is not assigned. ähnelt.
        /// </summary>
        internal static string ERR_1008 {
            get {
                return ResourceManager.GetString("ERR_1008", resourceCulture);
            }
        }
        
        /// <summary>
        ///   Sucht eine lokalisierte Zeichenfolge, die Duplicate join-point parameter &apos;{0}&apos; in &apos;{1}&apos;. ähnelt.
        /// </summary>
        internal static string ERR_1009 {
            get {
                return ResourceManager.GetString("ERR_1009", resourceCulture);
            }
        }
        
        /// <summary>
        ///   Sucht eine lokalisierte Zeichenfolge, die Can&apos;t interweave &apos;{0}&apos;: &apos;Advice.Initialize&apos; aspect methods mustn&apos;t bind generic parameters (&apos;{1}&apos;) coming from target method definitions (generic parameter &apos;{2}&apos; in &apos;{3}&apos;). Use parameter wildcards instead.  ähnelt.
        /// </summary>
        internal static string ERR_1010 {
            get {
                return ResourceManager.GetString("ERR_1010", resourceCulture);
            }
        }
        
        /// <summary>
        ///   Sucht eine lokalisierte Zeichenfolge, die Can&apos;t interweave private class &apos;{0}&apos;. ähnelt.
        /// </summary>
        internal static string ERR_1011 {
            get {
                return ResourceManager.GetString("ERR_1011", resourceCulture);
            }
        }
        
        /// <summary>
        ///   Sucht eine lokalisierte Zeichenfolge, die Can&apos;t interweave &apos;{0}&apos;: Parameters of type &apos;{1}&apos; are invalid. ähnelt.
        /// </summary>
        internal static string ERR_1012 {
            get {
                return ResourceManager.GetString("ERR_1012", resourceCulture);
            }
        }
        
        /// <summary>
        ///   Sucht eine lokalisierte Zeichenfolge, die Can&apos;t interweave &apos;{0}&apos;: The aspect method is expected to be declared as &apos;static&apos;. ähnelt.
        /// </summary>
        internal static string ERR_1013 {
            get {
                return ResourceManager.GetString("ERR_1013", resourceCulture);
            }
        }
        
        /// <summary>
        ///   Sucht eine lokalisierte Zeichenfolge, die Can&apos;t interweave &apos;{0}&apos;: {1} aspects mustn&apos;t use use parameterized constructors. ähnelt.
        /// </summary>
        internal static string ERR_1014 {
            get {
                return ResourceManager.GetString("ERR_1014", resourceCulture);
            }
        }
        
        /// <summary>
        ///   Sucht eine lokalisierte Zeichenfolge, die Can&apos;t interweave &apos;{0}&apos;: The aspect has no constructor that accepts {1} parameter(s) of type {2}. ähnelt.
        /// </summary>
        internal static string ERR_1015 {
            get {
                return ResourceManager.GetString("ERR_1015", resourceCulture);
            }
        }
        
        /// <summary>
        ///   Sucht eine lokalisierte Zeichenfolge, die Internal Error. ähnelt.
        /// </summary>
        internal static string ERR_9000 {
            get {
                return ResourceManager.GetString("ERR_9000", resourceCulture);
            }
        }
        
        /// <summary>
        ///   Sucht eine lokalisierte Zeichenfolge, die The type {0} is incompatible to array {1}.  ähnelt.
        /// </summary>
        internal static string ERRMSG_IncompatibleTypes {
            get {
                return ResourceManager.GetString("ERRMSG_IncompatibleTypes", resourceCulture);
            }
        }
        
        /// <summary>
        ///   Sucht eine lokalisierte Zeichenfolge, die The parameter has no type. ähnelt.
        /// </summary>
        internal static string ERRMSG_NoTypeParam {
            get {
                return ResourceManager.GetString("ERRMSG_NoTypeParam", resourceCulture);
            }
        }
        
        /// <summary>
        ///   Sucht eine lokalisierte Zeichenfolge, die Array parameters mustn&apos;t have a scalar value. Use &lt;element&gt; ... &lt;/element&gt; instead. ähnelt.
        /// </summary>
        internal static string ERRMSG_ParamValue {
            get {
                return ResourceManager.GetString("ERRMSG_ParamValue", resourceCulture);
            }
        }
    }
}
