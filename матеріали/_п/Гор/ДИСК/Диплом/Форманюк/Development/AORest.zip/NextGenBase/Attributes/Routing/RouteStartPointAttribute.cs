using System;

namespace NextGenBase.Attributes.Routing
{
    [AttributeUsage(AttributeTargets.Class)]
    public sealed class RouteStartPointAttribute : Attribute
    {
        public string StartPoint { get; private set; }

        public RouteStartPointAttribute(string startPoint = "")
        {
            StartPoint = startPoint;
        }
    }
}