﻿using System.Text;

namespace NextGenBase.Extensions
{
    public static class StringExtensions
    {
        public static string DecodeFromUtf8(this string utf8String)
        {            
            // copy the string as UTF-8 bytes.
            byte[] utf8Bytes = new byte[utf8String.Length];
            for (int i = 0; i < utf8String.Length; ++i)
            {
                //Debug.Assert( 0 <= utf8String[i] && utf8String[i] <= 255, "the char must be in byte's range");
                utf8Bytes[i] = (byte)utf8String[i];
            }

            return Encoding.UTF8.GetString(utf8Bytes, 0, utf8Bytes.Length);
        }

        public static string DecodeUtf8ToISO8859(this string utf8String)
        {
            Encoding iso = Encoding.GetEncoding("UTF-16LE");
            Encoding utf8 = Encoding.Unicode;
            byte[] utfBytes = utf8.GetBytes(utf8String);
            byte[] isoBytes = Encoding.Convert(utf8, iso, utfBytes);
            string msg = iso.GetString(isoBytes);
            return msg;
        }

        /// <summary>
        /// Formats the specified string.
        /// </summary>
        /// <param name="str">The string.</param>
        /// <param name="objs">The objs.</param>
        /// <returns></returns>
        public static string Format(this string str, params object[] objs)
        {
            return string.Format(str, objs);
        }

        public static string TrimNotNull(this string str)
        {
            return str == null ? null : str.Trim();
        }
    }
}
