﻿using NextGenBase.Helpers;

namespace NextGenBase.Interfaces.Servises
{
    public interface IInjectionService : IService
    {
        ActionContainer Invoke(ActionContainer container);
    }
}