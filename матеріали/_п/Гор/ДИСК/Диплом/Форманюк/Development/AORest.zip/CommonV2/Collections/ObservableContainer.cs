﻿using System;
using System.Collections.Generic;
using System.Linq;
using CommonV2.EventArgs;
using CommonV2.Extensions;
using CommonV2.Interfaces;

namespace CommonV2.Collections
{
    /// <summary>
    /// Provides generic key-related container with notification functionality 
    /// <para><remarks>Duplicates are not resolved inside the container</remarks></para>
    /// <para>See <see cref="CObservableReferenceCounter{T}"/> for a duplication-resolving container</para>
    /// </summary>
    public class CObservableContainer<T> : IObservableContainer<T>
    {
        #region Members

        protected Dictionary<int, List<T>> m_innerCollection;
        protected List<KeyValuePair<int, T>> m_rawCollection;

        #endregion

        #region ctors

        /// <summary>
        /// Initializes a new instance of the <see cref="CObservableContainer{T}"/> class.
        /// </summary>
        public CObservableContainer()
        {
            m_innerCollection = new Dictionary<int, List<T>>();
            m_rawCollection = new List<KeyValuePair<int, T>>();

            ApplyDefaultEventHandlers();
        }

        public CObservableContainer(int key)
            : this()
        {
            m_innerCollection.Add(key, new List<T>());
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CObservableContainer{T}"/> class.
        /// </summary>
        /// <param name="key">The key no.</param>
        /// <param name="array">The array.</param>
        public CObservableContainer(int key, IEnumerable<T> array)
            : this()
        {
            m_innerCollection.Add(key, new List<T>(array));
            OnAddRange(this, new NotificationEventArgs<IEnumerable<T>>(key, array));
        }

        #endregion

        #region Events

        /// <summary>
        /// Occurs on new item add.
        /// </summary>
        public event EventHandler<NotificationEventArgs<T>> OnAdd;

        /// <summary>
        /// Occurs on new range add
        /// </summary>
        public event EventHandler<NotificationEventArgs<IEnumerable<T>>> OnAddRange;

        /// <summary>
        /// Occurs on element change
        /// </summary>
        public virtual event EventHandler<NotificationChangeEventArgs<T>> OnChange;

        /// <summary>
        /// Occurs on collection re
        /// </summary>
        public event EventHandler<NotificationEventArgs<T>> OnClear;

        /// <summary>
        /// Occurs on item remove.
        /// </summary>
        public event EventHandler<NotificationEventArgs<T>> OnRemove;

        /// <summary>
        /// Occurs on remove range.
        /// </summary>
        public event EventHandler<NotificationEventArgs<IEnumerable<T>>> OnRemoveRange;

        #endregion

        #region Indexers

        /// <summary>
        /// <para>Gets or sets the <see cref="T"/> related to key.</para>
        /// <para><remarks>Duplicates are not resolved inside the container, so the first item would be targeted</remarks></para>
        /// <para><see cref="CObservableReferenceCounter{T}"/> for a duplication-resolving container</para>
        /// </summary>
        /// <value>
        /// The <see cref="T"/>.
        /// </value>
        /// <param name="key">The key.</param>
        /// <param name="item">The item.</param>
        /// <returns></returns>
        public virtual T this[int key, T item]
        {
            get { return m_innerCollection[key].FirstOrDefault(o => o.Equals(item)); } // just to overcome read-only property
            set
            {
                if (!Contains(key)) throw ThrowArgumentException(key);

                var targetCollection = m_innerCollection[key];
                OnChange(this, new NotificationChangeEventArgs<T>(key, item, value));
                m_innerCollection[key][targetCollection.IndexOf(item)] = value; // for sure change reference but not it's value
            }
        }

        public virtual T this[int key, int index]
        {
            get { return m_innerCollection[key][index]; } // just to overcome read-only property
            set
            {
                if (!Contains(key)) throw ThrowArgumentException(key);

                var targetCollection = m_innerCollection[key];
                OnChange(this, new NotificationChangeEventArgs<T>(key, targetCollection[index], value));
                m_innerCollection[key][index] = value;
            }
        }

        public virtual IEnumerable<T> this[int key]
        {
            get { return m_innerCollection[key].AsReadOnly(); }
        }

        #endregion

        #region Add methods

        /// <summary>
        /// <para>Adds the specified key to the container.</para>   
        /// <para><remarks>If container already contains key all data related to the key will be cleared.</remarks></para>
        /// </summary>        
        /// <param name="key">The key.</param>
        /// <param name="item">The item.</param>
        public virtual void Add(int key)
        {            
            if (Contains(key))
            {
                m_innerCollection[key].Clear();
                m_rawCollection.RemoveAll(o => o.Key == key);
            }
            else m_innerCollection.Add(key, new List<T>());
        }

        /// <summary>
        /// Adds the specified item related to key.
        /// </summary>
        /// <param name="key">The key.</param>
        /// <param name="item">The item.</param>
        public virtual void Add(int key, T item)
        {
            if (!Contains(key)) m_innerCollection.Add(key, new List<T>());
            m_innerCollection[key].Add(item);
            OnAdd(this, new NotificationEventArgs<T>(key, item));
        }

        /// <summary>
        /// Adds the range.
        /// </summary>
        /// <param name="key">The key.</param>
        /// <param name="items">The items.</param>
        public virtual void AddRange(int key, IEnumerable<T> items)
        {
            if (!Contains(key)) m_innerCollection.Add(key, new List<T>());
            m_innerCollection[key].AddRange(items);
            OnAddRange(this, new NotificationEventArgs<IEnumerable<T>>(key, items));
        }

        /// <summary>
        /// Inserts the specified item for key.
        /// </summary>
        /// <param name="key">The key.</param>
        /// <param name="index">The index.</param>
        /// <param name="item">The item.</param>
        public virtual void Insert(int key, int index, T item)
        {
            if (!Contains(key)) throw ThrowArgumentException(key);

            m_innerCollection[key].Insert(index, item);
            OnAdd(this, new NotificationEventArgs<T>(key, item));
        }

        #endregion

        #region Remove methods

        /// <summary>
        /// Removes the specified item from key.
        /// </summary>
        /// <param name="key">The key.</param>
        /// <param name="item">The item.</param>
        /// <returns></returns>
        public virtual bool Remove(int key, T item)
        {
            if (!Contains(key)) throw ThrowArgumentException(key);

            OnRemove(this, new NotificationEventArgs<T>(key, item));
            return m_innerCollection[key].Remove(item);
        }

        /// <summary>
        /// Removes item at specified index from key.
        /// </summary>
        /// <param name="key">The key.</param>
        /// <param name="index">The index.</param>
        public virtual void RemoveAt(int key, int index)
        {
            if (!Contains(key)) throw ThrowArgumentException(key);

            T item = m_innerCollection[key].ElementAt(index);
            OnRemove(this, new NotificationEventArgs<T>(key, item));
            m_innerCollection[key].RemoveAt(index);
        }

        /// <summary>
        /// Removes the range.
        /// </summary>
        /// <param name="key">The key.</param>
        /// <param name="items">The items.</param>
        public virtual void RemoveRange(int key, IEnumerable<T> items)
        {
            if (!Contains(key)) throw ThrowArgumentException(key);

            OnRemoveRange(this, new NotificationEventArgs<IEnumerable<T>>(key, items));
            m_innerCollection[key].RemoveAll(o => items.Contains(o));
        }

        /// <summary>
        /// Removes the range.
        /// </summary>
        /// <param name="key">The key.</param>
        /// <param name="index">The index.</param>
        /// <param name="count">The count.</param>
        public virtual void RemoveRange(int key, int index, int count)
        {
            if (!Contains(key)) throw ThrowArgumentException(key);

            OnRemoveRange(this, new NotificationEventArgs<IEnumerable<T>>(key, m_innerCollection[key].GetRange(index, count)));
            m_innerCollection[key].RemoveRange(index, count);
        }

        #endregion

        #region Clear

        /// <summary>
        /// Clears the items related to key
        /// </summary>
        /// <param name="key">The key.</param>
        public virtual void Clear(int key)
        {
            if (!Contains(key)) return;
            m_innerCollection[key].Clear();
            OnClear(this, new NotificationEventArgs<T>(key, default(T)));
        }        

        #endregion

        #region Common

        /// <summary>
        /// Determines whether collection contains item related to key.
        /// </summary>
        /// <param name="key">The key.</param>
        /// <param name="item">The item.</param>
        /// <returns></returns>
        public bool Contains(int key, T item)
        {
            return Contains(key) && m_innerCollection[key].Contains(item);
        }

        /// <summary>
        /// Determines whether the specified key exists.
        /// </summary>
        /// <param name="key">The key.</param>
        /// <returns></returns>
        public bool Contains(int key)
        {
            return m_innerCollection.ContainsKey(key);
        }

        /// <summary>
        /// Gets index of specified item for key.
        /// </summary>
        /// <param name="key">The key.</param>
        /// <param name="item">The item.</param>
        /// <returns></returns>
        public int IndexOf(int key, T item)
        {
            if (!Contains(key)) throw ThrowArgumentException(key);

            return m_innerCollection[key].IndexOf(item);
        }

        #endregion

        #region IEnumerable<T>
        /// <summary>
        /// Represents containers as IEnumerable
        /// </summary>
        /// <returns></returns>
        public IEnumerable<KeyValuePair<int, T>> AsEnumerable()
        {
            return m_rawCollection;
        }

        /// <summary>
        /// Returns an enumerator that iterates through a collection.
        /// </summary>
        /// <returns>
        /// An <see cref="T:System.Collections.IEnumerator" /> object that can be used to iterate through the collection.
        /// </returns>
        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return m_rawCollection.GetEnumerator();
        }
        #endregion

        #region ILookup

        /// <summary>
        /// Gets the count.
        /// </summary>
        /// <value>
        /// The count.
        /// </value>
        public int Count
        {
            get { return m_innerCollection.Count; }
        }

        /// <summary>
        /// Gets the <see cref="IEnumerable{T}"/> with the specified key.
        /// </summary>
        /// <value>
        /// The <see cref="IEnumerable{T}"/>.
        /// </value>
        /// <param name="key">The key.</param>
        /// <returns></returns>
        IEnumerable<T> ILookup<int, T>.this[int key]
        {
            get
            {
                if (!Contains(key)) m_innerCollection.Add(key, new List<T>());
                return m_innerCollection[key].AsReadOnly();
            }
        }

        /// <summary>
        /// Returns an enumerator that iterates through the collection.
        /// </summary>
        /// <returns>
        /// A <see cref="T:System.Collections.Generic.IEnumerator`1" /> that can be used to iterate through the collection.
        /// </returns>
        IEnumerator<IGrouping<int, T>> IEnumerable<IGrouping<int, T>>.GetEnumerator()
        {
            return m_rawCollection.ToLookup(k => k.Key, v => v.Value).GetEnumerator();
        }

        #endregion

        #region IDisposable

        public void Dispose()
        {
            DisposeDefaultEventHandlers();
        }

        #endregion

        #region EventHandlers

        protected virtual void OnAddRangeEventHandler(object sender, NotificationEventArgs<IEnumerable<T>> e)
        {
            if (e.Content != null)
                e.Content.ForEach(o => m_rawCollection.Add(NewPair(e.Key, o)));
        }

        protected virtual void OnAddEventHandler(object sender, NotificationEventArgs<T> e)
        {
            m_rawCollection.Add(NewPair(e.Key, e.Content));
        }

        protected virtual void OnAChangeEventHandler(object sender, NotificationChangeEventArgs<T> e)
        {
            m_rawCollection.Remove(NewPair(e.Key, e.OldContent));
            m_rawCollection.Add(NewPair(e.Key, e.Content));
        }

        protected virtual void OnClearEventHandler(object sender, NotificationEventArgs<T> e)
        {
            m_rawCollection.RemoveAll(o => o.Key == e.Key);
        }

        protected virtual void OnRemoveEventHandler(object sender, NotificationEventArgs<T> e)
        {
            m_rawCollection.Remove(NewPair(e.Key, e.Content));
        }

        protected virtual void OnRemoveRangeEventHandler(object sender, NotificationEventArgs<IEnumerable<T>> e)
        {
            if (e.Content != null) 
                e.Content.ForEach(o => m_rawCollection.Remove(NewPair(e.Key, o)));
        }

        #endregion

        #region Helpers        

        /// <summary>
        /// Creates new KeyValuePair
        /// </summary>
        /// <param name="key">The key.</param>
        /// <param name="item">The item.</param>
        /// <returns></returns>
        protected KeyValuePair<int, T> NewPair(int key, T item)
        {
            return new KeyValuePair<int, T>(key, item);
        }

        /// <summary>
        /// Throws the argument exception.
        /// </summary>
        /// <param name="key">The key.</param>
        /// <returns></returns>
        protected ArgumentException ThrowArgumentException(int key, string errorMessage = "Collection does not contain information related to key {0}")
        {
            return new ArgumentException(string.Format(errorMessage, key));
        }
        
        private void ApplyDefaultEventHandlers()
        {
            OnAdd += OnAddEventHandler;
            OnAddRange += OnAddRangeEventHandler;
            OnChange += OnAChangeEventHandler;
            OnRemove += OnRemoveEventHandler;
            OnRemoveRange += OnRemoveRangeEventHandler;
            OnClear += OnClearEventHandler;
        }

        private void DisposeDefaultEventHandlers()
        {
            OnAdd -= OnAddEventHandler;
            OnAddRange -= OnAddRangeEventHandler;
            OnChange -= OnAChangeEventHandler;
            OnRemove -= OnRemoveEventHandler;
            OnRemoveRange -= OnRemoveRangeEventHandler;
            OnClear -= OnClearEventHandler;
        }

        #endregion
    }
}
