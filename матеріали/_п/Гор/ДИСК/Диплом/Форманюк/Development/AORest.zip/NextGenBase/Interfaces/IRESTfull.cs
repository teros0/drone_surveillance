﻿using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using NextGenBase.Attributes.Routing;

namespace NextGenBase.Interfaces
{
    public interface IRESTfull<T> : IRESTfullSet<T>, IRESTfullGet        
    {                
    }

    public interface IRESTfullGet : IRESTGet, IRESTSearch, IRESTReference
    {        
    }

    public interface IRESTfullSet<T> :
        IRESTPost<T>,
        IRESTPatch,
        IRESTDelete,
        IRESTPut<T>,
        IRESTSearch
    {        
    }

    public interface IRESTSearch : IRESTGet
    {
        HttpResponseMessage GetSearchAction(HttpRequestMessage request, string filterString);

        HttpResponseMessage GetSearchDetailsAction(HttpRequestMessage request, string filterString);
    }

    public interface IRESTReference : IRESTGet
    {
        HttpResponseMessage Reference(HttpRequestMessage request);
        HttpResponseMessage RAML(HttpRequestMessage request);
    }

    public interface IRESTGet
    {        
        HttpResponseMessage GetAllDetailsAction(HttpRequestMessage request);
        
        HttpResponseMessage GetAllAction(HttpRequestMessage request);
        
        HttpResponseMessage GetByIdAction(HttpRequestMessage request, int id);
        
        HttpResponseMessage GetPropertyAction(HttpRequestMessage request, int id, string propertyName);               
    }

    public interface IRESTPost<T>
    {        
        //Task<HttpResponseMessage> AddAction(HttpRequestMessage request, T obj);
        //Task<HttpResponseMessage> AddMultipleAction(HttpRequestMessage request);
        //Task<HttpResponseMessage> GetPartialAction(HttpRequestMessage request, int id, Dictionary<string, object> dictionary);
        Task<HttpResponseMessage> AddMultipelAction(HttpRequestMessage request);
    }

    public interface IRESTPatch
    {        
        //HttpResponseMessage SingleChangeAction(HttpRequestMessage request, object id, string propertyName, object newValue);
        Task<HttpResponseMessage> ChangeMultipleAction(HttpRequestMessage request);
        Task<HttpResponseMessage> ChangeAction(HttpRequestMessage request, int id);        
    }

    public interface IRESTDelete
    {        
        HttpResponseMessage DeleteAction(HttpRequestMessage request, int id);
        Task<HttpResponseMessage> DeleteMultipleEntitiesAction(HttpRequestMessage request);
        HttpResponseMessage DeleteMultipleIdsAction(HttpRequestMessage request, IEnumerable<int> ids);
    }

    public interface IRESTPut<T>
    {        
        Task<HttpResponseMessage> FullChangeAction(HttpRequestMessage request, int id);
        Task<HttpResponseMessage> FullMultipleChangeAction(HttpRequestMessage request);
    }
}