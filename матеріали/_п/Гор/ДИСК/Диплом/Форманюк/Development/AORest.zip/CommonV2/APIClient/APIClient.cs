﻿using System;
using System.IO;
using System.Net;
using System.Net.Security;
using System.Text;

namespace CommonV2.APIClient
{
    public class APIClient
    {
        public string Url { get; set; }
        public HttpWebRequest Request { get; set; }       

        public byte[] Data { get; private set; }

        public static class Method
        {
            public const string GET = "GET";
            public const string POST = "POST";
        }

        public HttpWebRequest CreateRequest(string method, string requestString = "", string postData = "", string origin = "")
        {
            var httpWReq = (HttpWebRequest)WebRequest.Create(Url + requestString);            

            var encoding = new ASCIIEncoding();
            Data = encoding.GetBytes(postData);
            httpWReq.Method = method;
            httpWReq.ContentType = "text/html; charset = utf-8";
            httpWReq.ContentLength = Data.Length;
            httpWReq.Headers.Add("Access-Control-Allow-Origin", "*");
            httpWReq.Headers.Add("Access-Control-Allow-Headers", "Origin, Content-Type, Accept, Authorization, X-Request-With");
            httpWReq.Timeout = 5 * 60 * 1000;
            if (!string.IsNullOrEmpty(origin))
            {
                httpWReq.Headers.Add("Origin", origin);
            }

            Request = httpWReq;

            return httpWReq;
        }

        public string GetResponse(string key = "", HttpWebRequest request = null)
        {
            try
            {
                request = request ?? Request;
                if (request == null) throw new ArgumentException("No request exists");

                string result;

                InitiateSSLTrust();

                if (APIClient.Method.GET == Request.Method)
                {
                    using (var response = (WebResponse) request.GetResponse())
                    {
                        result = new StreamReader(response.GetResponseStream()).ReadToEnd();

                        if (!string.IsNullOrEmpty(key))
                        {
                            result = result.Trim(new[] {'\'', '"'});
                            result = Security.Decrypt(result, key);
                        }
                    }
                }
                else
                {

                    using (var stream = request.GetRequestStream())
                    {
                        stream.Write(Data, 0, Data.Length);

                        using (var response = (WebResponse) request.GetResponse())
                        {

                            result = new StreamReader(response.GetResponseStream()).ReadToEnd();

                            if (!string.IsNullOrEmpty(key))
                            {
                                result = result.Trim(new[] {'\'', '"'});
                                result = Security.Decrypt(result, key);
                            }
                        }
                    }
                }

                return result;
            }catch
            {
                return null;
            }
        }

        public APIClient(string url)
        {
            Url = url.TrimEnd(new[]{'/'});          
        }

        public static void InitiateSSLTrust()
        {
            try
            {
                //Change SSL checks so that all checks pass
                ServicePointManager.ServerCertificateValidationCallback =
                   new RemoteCertificateValidationCallback(
                        delegate
                        { return true; }
                    );
            }
            catch (Exception ex)
            {                
            }
        }
    }    
}
