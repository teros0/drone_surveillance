﻿using System.Collections.Generic;
using System.Net.Http;

namespace NextGenBase.Interfaces.Servises
{
    public interface IQueryService<TEntity> : IService
    {
        IEnumerable<KeyValuePair<string, object>> Parse(HttpRequestMessage request); 
    }
}