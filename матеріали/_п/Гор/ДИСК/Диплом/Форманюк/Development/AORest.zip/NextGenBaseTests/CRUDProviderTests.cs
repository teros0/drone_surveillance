﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Net.Http;
using System.Reflection;
using System.Web.Http;
using jetMapper.Extensions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NextGenBase.Helpers;
using WebApplication.Controllers;
using WebApplication.Models;
using NextGenBase;
namespace NextGenBase.Tests
{
    [TestClass()]
    public class CRUDProviderTests
    {
        [TestMethod()]
        public void ConfigureTest()
        {
            CRUDProvider.Configure(new HttpConfiguration(), Assembly.GetAssembly(typeof(TestController)));
            var test = new TestController();
        }
    }
}

namespace NextGenBaseTests
{
    [TestClass()]
    public class CRUDProviderTests
    {
        public class TestClass
        {
            public string Name { get; set; }
            public int Value { get; set; }
        }

        [TestMethod]
        public void ExpressionTree()
        {
            var tt = new TestClass();
            List<TestClass> t = new List<TestClass>
            {
                new TestClass {Name = "123", Value = 5},
                new TestClass {Name = "456", Value = 6}
            };

            ParameterExpression pe = Expression.Parameter(typeof(TestClass), "company");

            Expression left = Expression.Property(pe, typeof(TestClass).GetProperty("Name"));//GetMethod("ToLower", System.Type.EmptyTypes));
            Expression right = Expression.Constant("123");
            Expression e1 = Expression.Equal(left, right);

            MethodCallExpression whereCallExpression = Expression.Call(
                typeof(Queryable),
                "Where",
                new Type[] { t.AsQueryable().ElementType },
                t.AsQueryable().Expression,
                Expression.Lambda<Func<TestClass, bool>>(e1, new ParameterExpression[] { pe }));

            IQueryable<TestClass> results = t.AsQueryable().Provider.CreateQuery<TestClass>(whereCallExpression);

            Assert.AreEqual(results.Single().Name, "123");
        }               

        [TestMethod()]
        public void GetDetailsActionTest()
        {
            CRUDProvider.Configure(new HttpConfiguration(), Assembly.GetAssembly(typeof(TestController)));
            // Arrange
            RozkladController controller = new RozkladController();

            // Act
            var result = controller.GetAllDetailsAction(new HttpRequestMessage());
            var f = result.As<IEnumerable<object>>().First();

            //// Assert
            Assert.IsNotNull(result);
            //Assert.IsTrue(f is int);
            //Assert.AreEqual("value1", result.ElementAt(0));
            //Assert.AreEqual("value2", result.ElementAt(1));
        }        

        [TestMethod()]
        public void GetActionTest1()
        {
            CRUDProvider.Configure(new HttpConfiguration(), Assembly.GetAssembly(typeof(TestController)));
            // Arrange
            RozkladController controller = new RozkladController();

            // Act
            var result = controller.GetAllAction(new HttpRequestMessage());
            var f = result.As<IEnumerable<object>>().First();

            //// Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(f is int);
            //Assert.AreEqual("value1", result.ElementAt(0));
            //Assert.AreEqual("value2", result.ElementAt(1));
        }

        [TestMethod()]
        public void GetActionTest12()
        {
            CRUDProvider.Configure(new HttpConfiguration(), Assembly.GetAssembly(typeof(TestController)));
            // Arrange
            var controller = new TestController();

            // Act
            var result = controller.GetAllAction(new HttpRequestMessage());

            object test;
            var f = result.TryGetContentValue(out test);
            var t = test.As<IEnumerable<object>>().First();            

            //// Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(f);
            Assert.IsTrue(t is int);
            //Assert.AreEqual("value1", result.ElementAt(0));
            //Assert.AreEqual("value2", result.ElementAt(1));
        }

        [TestMethod()]
        public void GetActionTest2()
        {
            CRUDProvider.Configure(new HttpConfiguration(), Assembly.GetAssembly(typeof(TestController)));
            // Arrange
            RozkladController controller = new RozkladController();

            // Act
            var result = controller.GetByIdAction(new HttpRequestMessage(), 1);
            object test;
            var f = result.TryGetContentValue(out test);
            var t = test as ScheduleItem;

            //// Assert
            Assert.IsNotNull(t);
        }

        [TestMethod()]
        public void SearchActionTest()
        {
            CRUDProvider.Configure(new HttpConfiguration(), Assembly.GetAssembly(typeof(TestController)));
            // Arrange
            RozkladController controller = new RozkladController();

            // Act
            var result = controller.GetSearchAction(new HttpRequestMessage(), "Id == 1 && Id == 2");
            var f = result as IEnumerable<object>;

            //// Assert
            Assert.IsNotNull(result);
            var enumerable = f as IList<object> ?? f.ToList();
            Assert.AreSame(enumerable.Count(), 2);
            Assert.IsFalse(enumerable.All(o => o is int));
        }

        [TestMethod()]
        public void SearchDetailsActionTest()
        {
            CRUDProvider.Configure(new HttpConfiguration(), Assembly.GetAssembly(typeof(TestController)));
            // Arrange
            RozkladController controller = new RozkladController();

            // Act
            var result = controller.GetSearchDetailsAction(new HttpRequestMessage(), "Id == 1 && Id == 2");
            var f = result as IEnumerable<ScheduleItem>;

            //// Assert
            Assert.IsNotNull(result);
            var enumerable = f as IList<ScheduleItem> ?? f.ToList();
            Assert.AreSame(enumerable.Count(), 2);
            Assert.IsFalse(enumerable.All(o => o is ScheduleItem));
        }

        [TestMethod()]
        public void AddActionTest()
        {
            CRUDProvider.Configure(new HttpConfiguration(), Assembly.GetAssembly(typeof(TestController)));
            var controller = new TestController();

            var obj = new TestDataModel
            {
                Value1 = "123",
                Value2 = "456",
                Value3 = "789",
                Value4 = 345
            };

            string json = fastJSON.JSON.ToJSON(obj);

            //var response = controller.AddAction(new HttpRequestMessage(), obj);

        }

        [TestMethod()]
        public void AddActionManyTest()
        {
            CRUDProvider.Configure(new HttpConfiguration(), Assembly.GetAssembly(typeof(TestController)));
            var controller = new TestController();

            var lst = new List<TestDataModel>();

            var obj = new TestDataModel
            {
                Value1 = "123",
                Value2 = "456",
                Value3 = "789",
                Value4 = 345
            };

            lst.Add(obj);
            lst.Add(obj);

            string json = fastJSON.JSON.ToJSON(lst);

            //var response = controller.AddAction(new HttpRequestMessage(), lst);

        }

        [TestMethod()]
        public void FullChangeActionTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void ChangeActionTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void PerformSingleChangeTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void PerformDeleteTest()
        {
            Assert.Fail();
        }
    }
}
