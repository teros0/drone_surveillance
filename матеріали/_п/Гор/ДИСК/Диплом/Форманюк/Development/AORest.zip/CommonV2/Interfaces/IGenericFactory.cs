﻿using System;

namespace CommonV2.Interfaces
{
    public interface IGenericFactory<T> : IFactory<T>
    {
        T Create(object id, object[] parameters = null);
        void Register(object id, Func<object[], T> ctor);
    }
}
