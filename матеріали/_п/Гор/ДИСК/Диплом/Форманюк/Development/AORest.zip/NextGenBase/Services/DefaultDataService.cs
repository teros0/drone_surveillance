﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using jetMapper;
using NextGenBase.Extensions;
using NextGenBase.Helpers;
using NextGenBase.Interfaces;
using NextGenBase.Interfaces.Servises;

namespace NextGenBase.Services
{
    public class DefaultDataService : IDataService
    {        
        public object GetId(object obj)
        {
            return obj.Proxy()[GetIdName(obj)];
        }

        public string GetIdName(object obj)
        {
            return "Id";
        }        

        private TS _map<T, TS>(T obj) 
            where TS : new()
        {
            return Mapper.Create<T, TS>().Do(obj);
        }        

        public TDestination Map<TSource, TDestination>(TSource data) 
            where TDestination : new()
        {
            return _map<TSource, TDestination>(data);
        }

        void IDisposable.Dispose()
        {

        }

        public object Environment
        {
            get;
            set;
        }
    }
}
