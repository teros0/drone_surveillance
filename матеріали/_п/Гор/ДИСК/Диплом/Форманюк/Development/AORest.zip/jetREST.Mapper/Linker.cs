﻿using System;
using System.Collections.Generic;
using System.Linq;
using NextGenBase.Extensions;

namespace NextGenBase.Helpers
{
    public class Linker<T>
    {
        readonly LinkedList<Func<T, T>> _list = new LinkedList<Func<T, T>>();

        public Linker(Func<T, T> first)
        {
            if (first != null)
                _list.AddLast(first);
        }

        public Func<T, T> Do
        {
            get { return _action; }
        }

        private Func<T, T> _action
        {
            get
            {
                var result = default(T).If();
                Action<T> temp = arg => {
                    result = result.And(o => arg);
                    if(!_list.Any()) return;
                    var element = _list.First;
                    while (element != null)
                    {
                        result = result.And(element.Value);
                        element = element.Next;
                    }
                };

                return arg => { temp(arg); return result.Value; };
            }
        }

        public Linker<T> AddLast(Func<T, T> right)
        {
            _list.AddLast(right);
            return this;
        }

        public Linker<T> AddFirst(Func<T, T> right)
        {
            _list.AddFirst(right);
            return this;
        }

        #region Operators

        public static implicit operator Func<T, T>(Linker<T> proxy)
        {
            return proxy._action;
        }

        public static implicit operator LinkedList<Func<T, T>>(Linker<T> proxy)
        {
            return proxy._list;
        }

        public static Linker<T> operator <(Linker<T> left, Func<T, T> right)
        {
            left._list.AddFirst(right);
            return left;
        }

        public static Linker<T> operator >(Linker<T> left, Func<T, T> right)
        {
            left._list.AddLast(right);
            return left;
        }

        public static T operator <(Linker<T> left, T obj)
        {
            return left.Do(obj);
        }

        public static T operator >(Linker<T> left, T obj)
        {
            return left.Do(obj);
        }
        #endregion
    }
}