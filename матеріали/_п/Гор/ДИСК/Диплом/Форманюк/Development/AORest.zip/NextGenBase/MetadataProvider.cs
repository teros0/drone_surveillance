﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using NextGenBase.Attributes;
using NextGenBase.Attributes.Db;

namespace NextGenBase
{
    internal static class MetadataProvider
    {
        public static PropertyInfo[] GetDataMetadata(Type type)
        {
            return type.GetProperties();
        }

        public static Dictionary<string, string> GetPropertiesNameBindings(Type local)
        {
            return local.GetProperties()
                .Select(o => new { Property = o, Atr = o.GetCustomAttribute<DbFieldAttribute>() })
                .ToDictionary(key => key.Property.Name, value => value.Atr != null ? value.Atr.DbFieldName : value.Property.Name);
        }

        public static Dictionary<string, string> GetClassNameBindings(Type local)
        {
            return local.GetProperties()
                .Select(o => new { Property = o, Atr = o.GetCustomAttribute<DbTableAttribute>() })
                .ToDictionary(key => key.Property.Name, value => value.Atr != null ? value.Atr.DbTableName : value.Property.Name);
        }

        public static Func<S, T> BuildGetAccessor<S, T>(Expression<Func<S, T>> propertySelector)
        {
            return propertySelector.GetPropertyInfo().GetGetMethod().CreateDelegate<Func<S, T>>();
        }

        public static Action<S, T> BuildSetAccessor<S, T>(Expression<Func<S, T>> propertySelector)
        {
            return propertySelector.GetPropertyInfo().GetSetMethod().CreateDelegate<Action<S, T>>();
        }

        public static T CreateDelegate<T>(this MethodInfo method) where T : class
        {
            return Delegate.CreateDelegate(typeof(T), method) as T;
        }

        public static T CreateBoundedDelegate<T>(this MethodInfo method) where T : class
        {
            return Delegate.CreateDelegate(typeof(T), null, method) as T;
        }

        public static PropertyInfo GetPropertyInfo<S, T>(this Expression<Func<S, T>> propertySelector)
        {
            var body = propertySelector.Body as MemberExpression;
            if (body == null)
                throw new MissingMemberException("something went wrong");

            return body.Member as PropertyInfo;
        }        
    }
}
