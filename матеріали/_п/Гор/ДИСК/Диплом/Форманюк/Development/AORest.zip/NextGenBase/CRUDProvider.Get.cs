﻿using System.Linq;
using System.Net;
using System.Net.Http;
using jetMapper.Extensions;
using NextGenBase.Attributes.Routing;
using NextGenBase.Extensions;
using NextGenBase.Helpers;
using NextGenBase.Interfaces;

namespace NextGenBase
{
    public abstract partial class CRUDProvider<T, TEntity> : IRESTGet, IRESTSearch
    {
        #region Get

        //[Version(1.1)]
        [System.Web.Http.AcceptVerbs("GET")]
        //[System.Web.Http.ActionName("GetAllAction")]
        [Route("GetAllAction", typeof(IRESTGet), "Ids/{controller}")]
        public virtual HttpResponseMessage GetAllAction(HttpRequestMessage request)
        {
            return ValidateAndInvoke(request,
                (ActionContainer<IQueryable<object>> container) => 
                    _get(CreateContainer(DataProvider.AsQueryable())
                        .Apply(o => o.Errors = container.Errors)
                        .Apply(o => o.Exceptions = container.Exceptions))
                    .ToDictionary(key => key, DataService.GetId)
                    .Select(o => o.Value).AsQueryable(),
                HttpStatusCode.OK,
                null,
                InterfaceTypes[Interface.Get]);
        }
        
        [System.Web.Http.AcceptVerbs("GET")]
        [Route("GetAllDetailsAction", typeof(IRESTGet), "/{controller}")]
        public virtual HttpResponseMessage GetAllDetailsAction(HttpRequestMessage request)
        {            
            return ValidateAndInvoke(request,
                (ActionContainer<IQueryable<T>> container) =>
                    _get(CreateContainer(DataProvider.AsQueryable())
                        .Apply(o => o.Errors = container.Errors)
                        .Apply(o => o.Exceptions = container.Exceptions))
                    .ToDictionary(key => key, DataService.Map<TEntity, T>)
                    .Select(o => o.Value).AsQueryable(),
                HttpStatusCode.OK,
                null,
                InterfaceTypes[Interface.Get]);
        }

        [System.Web.Http.AcceptVerbs("GET")]
        //[System.Web.Http.ActionName("GetByIdAction")]
        [Route("GetByIdAction", typeof(IRESTGet), "/{controller}/{id}")]
        public virtual HttpResponseMessage GetByIdAction(HttpRequestMessage request, int id)
        {
            return ValidateAndInvoke(request,
                (ActionContainer<T> container) =>
                    DataService.Map<TEntity, T>(DataProvider.Find(id)),
                HttpStatusCode.OK,
                null,
                InterfaceTypes[Interface.Get]);
        }

        //[System.Web.Http.ActionName("GetPropertyAction")]
        [System.Web.Http.AcceptVerbs("GET")]
        [Route("GetPropertyAction", typeof(IRESTGet), "/{controller}/{id}/{propertyName}")]
        public virtual HttpResponseMessage GetPropertyAction(HttpRequestMessage request, int id, string propertyName)
        {
            return ValidateAndInvoke(request,
                (ActionContainer<object> container) =>
                    DataService.Map<TEntity, T>(DataProvider.Find(id)).Proxy()[propertyName],
                HttpStatusCode.OK,
                null,
                InterfaceTypes[Interface.Get]);
        }

        [System.Web.Http.AcceptVerbs("GET")]
        [Route("GetSearchAction", typeof(IRESTSearch), "/Search/Ids/{controller}/{filterString}")]
        public virtual HttpResponseMessage GetSearchAction(HttpRequestMessage request, string filterString)
        {
            return ValidateAndInvoke(request,
                (ActionContainer<IQueryable<object>> container) => 
                    __search(filterString).Value
                    .ToDictionary(key => key, DataService.GetId)
                    .Select(o => o.Value).AsQueryable(),
                HttpStatusCode.OK,
                null,
                InterfaceTypes[Interface.Search]);
        }

        [System.Web.Http.AcceptVerbs("GET")]
        [Route("GetSearchDetailsAction", typeof(IRESTSearch), "Search/{controller}/{filterString}")]
        public virtual HttpResponseMessage GetSearchDetailsAction(HttpRequestMessage request, string filterString)
        {
            return ValidateAndInvoke(request,
                (ActionContainer<IQueryable<T>> container) => 
                    __search(filterString).Value
                    .ToDictionary(key => key, DataService.Map<TEntity, T>)
                    .Select(o => o.Value).AsQueryable(),
                HttpStatusCode.OK,
                null,
                InterfaceTypes[Interface.Search]);
        }

        protected IQueryable<TEntity> _get(ActionContainer<IQueryable<TEntity>> container)
        {
            return _chainInvoker(InterfaceTypes[Interface.Get], container)
                .Apply(o => ControllerMetadatas[GetType()].CustomeServicesChain[InterfaceTypes[Interface.Get]](o))
                .Value;
        }

        #endregion
    }
}