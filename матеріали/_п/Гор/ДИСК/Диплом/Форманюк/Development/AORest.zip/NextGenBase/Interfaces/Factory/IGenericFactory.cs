﻿using System;

namespace NextGenBase.Interfaces.Factory
{
    public interface IGenericFactory<T> : IFactory<T>
    {
        T Create(object id, object[] parameters = null);
        void Register(object id, Func<object[], T> ctor);
    }
}
