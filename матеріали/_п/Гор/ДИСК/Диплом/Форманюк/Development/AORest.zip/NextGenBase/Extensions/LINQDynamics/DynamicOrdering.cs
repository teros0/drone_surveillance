using System.Linq.Expressions;

namespace NextGenBase.Extensions.LINQDynamics
{
    internal class DynamicOrdering
    {
        public Expression Selector;
        public bool Ascending;
    }
}