﻿using System;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Reflection;
using System.Web.Http.Description;
using NextGenBase.Attributes;
using NextGenBase.Attributes.Routing;
using NextGenBase.Interfaces;
using RAMLSharp;

namespace NextGenBase
{
    public abstract partial class CRUDProvider<T, TEntity> : IRESTReference
    {
         #region Documentation        

        [ApiExplorerSettings(IgnoreApi = true)]
        [System.Web.Http.AcceptVerbs("GET")]
        [Route("RAML", typeof(IRESTReference), "RAML/{controller}")]
        public HttpResponseMessage RAML(HttpRequestMessage request)
        {
            var result = new HttpResponseMessage(HttpStatusCode.OK);
            var controllerCustomAttr = this.GetType().GetCustomAttribute<VersionAttribute>();            
            var r = new RAMLMapper(this);
            var name = this.GetType().Name;
            var model = r.WebApiToRamlModel(new Uri("http://api.doc/" + name),
                name, 
                controllerCustomAttr == null ? "1" : controllerCustomAttr.StringRepresentation, 
                DataPresenterService.MediaTypeFormatter.ToString(), 
                "");
            model.Routes.Where(o => !o.UrlTemplate.Contains(name.Replace("Controller", string.Empty))).ToList()
                .ForEach(o => model.Routes.Remove(o));
            var t = CRUDProvider.TypeOfView;
            //this.GetType().GetMethods()
            //    .Where(o => o.GetCustomAttribute<BaseRouteAttribute>() != null)
            //    .Select(o => new { Response = o.GetCustomAttributes<ResponseBodyAttribute>(), Method = o.Name, Route = o.GetCustomAttribute<BaseRouteAttribute>() })
            //    .Where(o => o.Response != null)
            //    .ForEach(x =>                
            //        x.Response.ForEach(xx =>

            //            model.Routes.Single(o => 
            //                o.UrlTemplate.Replace(name.Replace("Controller", string.Empty), "{controller}") == x.Route.Route)
            //             .Apply(c => c.Responses.Single(rr => rr.StatusCode == xx.StatusCode).Example = CRUDProvider.TypeOfView)
            //        )                    
            //    );

            var data = model.ToString();

            result.Content = new StringContent(data);
            result.Content.Headers.ContentType = new MediaTypeHeaderValue("text/html");
            result.Content.Headers.ContentLength = data.Length;
            return result;
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        [System.Web.Http.AcceptVerbs("GET")]
        [Route("Reference", typeof (IRESTReference), "Reference/{controller}")]
        public HttpResponseMessage Reference(HttpRequestMessage request)
        {
            var result = request.CreateResponse();
            var path = "http://" + request.RequestUri.Authority + "/RAML/" + this.GetType().Name.Replace("Controller", string.Empty);
            var content = string.Format(html, path);
            result.Content = new StringContent(content);
            result.Content.Headers.ContentType = new MediaTypeHeaderValue("text/html");
            result.Content.Headers.ContentLength = content.Length;
            return result;
            //var response = request.CreateResponse(HttpStatusCode.Moved);
            //response.Headers.Location = new Uri("http://" + request.RequestUri.Host + "RAML/" + this.GetType().Name.Replace("Controller", string.Empty));
            //return response;
        }

        const string html = @"<!doctype html>
                <html lang='en'>
                    <head>
                        <meta charset='UTF-8'>
                        <meta name='viewport' content='width=device-width, initial-scale=1'>
                        <title>API Console</title>
                        <link href='https://cdn.rawgit.com/mulesoft/api-console/master/dist/styles/api-console-light-theme.css' rel='stylesheet' class='theme'>
                    </head>
                <body ng-app='ramlConsoleApp' ng-cloak class='raml-console-body'>
                    <raml-initializer></raml-initializer>
                    <raml-console with-root-documentation src='{0}'></raml-console>
                    <script src='https://cdn.rawgit.com/mulesoft/api-console/master/dist/scripts/api-console-vendor.js'></script>
                    <script src='https://cdn.rawgit.com/mulesoft/api-console/master/dist/scripts/api-console.js'></script>
                    <script>
                        $.noConflict();	
                    </script>
                </body>
            </html>";

        #endregion       
    }
}