﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Threading.Tasks;
using jetREST.Mapper.Extensions;
using NextGenBase.Helpers;

namespace jetREST.Mapper
{
    public class DataProxy
    {        
        public Dictionary<string, object> RawView;

        public static DataProxy<TEntity> Create<TEntity>(TEntity entity)
        {
            return new DataProxy<TEntity>(entity);
        }

        protected static readonly Lazy<Dictionary<Type, Dictionary<string, object>>> AccessObjects =
            new Lazy<Dictionary<Type, Dictionary<string, object>>>();

        protected static readonly Lazy<Dictionary<Type, Dictionary<string, Delegate>>> MethodsDictionary =
            new Lazy<Dictionary<Type, Dictionary<string, Delegate>>>();
    }
    
    public class DataProxy<TEntity> : DataProxy, IEnumerable<string>
    {
        readonly Type _type;
        private ReadOnlyDictionary<string, Delegate> _methods;
        private ReadOnlyDictionary<string, object> _accessObjects; 

        public TEntity Raw { get; private set; }

        private IEnumerable<string> _properties 
        {
            get
            {
                return _accessObjects.Keys.AsEnumerable();
            }
        }

        public DataProxy(TEntity entity, bool registerMethods = false)            
        {
            RawView = new Dictionary<string, object>();
            _type = entity is DataProxy<TEntity> ? ((DataProxy<TEntity>)entity).Raw.GetType() : entity.GetType();            
            if (!AccessObjects.Value.ContainsKey(_type)) BuildAccessors(_type, this);
            _accessObjects = new ReadOnlyDictionary<string, object>
                (AccessObjects.Value[_type].As<Dictionary<string, object>>());

            Raw = entity;

            if (!MethodsDictionary.Value.ContainsKey(_type)) MethodsDictionary.Value.Add(_type, new Dictionary<string, Delegate>());

            if (registerMethods) RegisterMethods(this);            
            _methods = new ReadOnlyDictionary<string, Delegate>(MethodsDictionary.Value[_type]);            
        }

        public DataProxy(bool registerMethods = false)
        {            
            RawView = new Dictionary<string, object>();
            _type = typeof(TEntity);
            if (!AccessObjects.Value.ContainsKey(_type)) BuildAccessors(_type, this);
            _accessObjects = new ReadOnlyDictionary<string, object>
                (AccessObjects.Value[_type].As<Dictionary<string, object>>());

            if (!MethodsDictionary.Value.ContainsKey(_type)) MethodsDictionary.Value.Add(_type, new Dictionary<string, Delegate>());

            if (registerMethods) RegisterMethods(this);            
            _methods = new ReadOnlyDictionary<string, Delegate>(MethodsDictionary.Value[_type]);                        
        }

        private static void RegisterMethods(DataProxy<TEntity> proxy)
        {
            var typeOfEntity = proxy._type;
            foreach (var m in typeOfEntity.GetMethods())
            {                
                MethodsDictionary.Value[typeOfEntity][m.Name] =
                    DelegateExtensions.DelegateHelper.CreateCompatibleDelegate<Delegate>(proxy.Raw, m);                                    
            }           
        }

        internal DataProxy<TEntity> RegisterMethod<T>(string name, T method)
        {
            MethodsDictionary.Value[_type][name] = method.As<Delegate>();
            return this;
        }

        public static void Cache()
        {
            BuildAccessors(typeof(TEntity), null);            
        }

        #region Helpers

        private static Func<T, object> GetValueGetter<T>(PropertyInfo propertyInfo)
        {
            var type = typeof (TEntity);
            if (!(type == propertyInfo.DeclaringType || type == propertyInfo.ReflectedType))
            {
                return arg => DelegateExtensions.DelegateHelper.CreateCompatibleDelegate<Func<object>>(arg, propertyInfo.GetMethod)();
            }

            var instance = Expression.Parameter(propertyInfo.DeclaringType, "i");
            var property = Expression.Property(instance, propertyInfo);
            var convert = Expression.TypeAs(property, typeof (object));
            return (Func<T, object>) Expression.Lambda(convert, instance).Compile();
        }

        private static Action<T, object> GetValueSetter<T>(PropertyInfo propertyInfo)
        {
            var type = typeof(T);
            if (!(type == propertyInfo.DeclaringType || type == propertyInfo.ReflectedType))
            {
                return (arg1, o) => DelegateExtensions.DelegateHelper.CreateCompatibleDelegate<Action<object>>(arg1, propertyInfo.SetMethod)(o);
            }

            var instance = Expression.Parameter(propertyInfo.DeclaringType, "i");
            var argument = Expression.Parameter(typeof (object), "a");
            var setterCall = Expression.Call(
                instance,
                propertyInfo.GetSetMethod(),
                Expression.Convert(argument, propertyInfo.PropertyType));
            return (Action<T, object>) Expression.Lambda(setterCall, instance, argument)
                .Compile();
        }

        private static void BuildAccessors(Type type, DataProxy<TEntity> obj)
        {            
            if (AccessObjects.Value.ContainsKey(type)) return;

            AccessObjects.Value.Add(type, new Dictionary<string, object>());

            foreach (var o in type.GetProperties())            
            {
                if (AccessObjects.Value[type].ContainsKey(o.Name) && o.DeclaringType == type)
                {
                    AccessObjects.Value[type][o.Name] = new AccessObject<TEntity, object>
                    {
                        PropertyInfo = o,
                        Get = o.CanRead ? GetValueGetter<TEntity>(o) : null,
                        Set = o.CanWrite ? GetValueSetter<TEntity>(o) : null
                    };
                }
                else if (!AccessObjects.Value[type].ContainsKey(o.Name))
                {
                    AccessObjects.Value[type].Add(o.Name, new AccessObject<TEntity, object>
                    {
                        PropertyInfo = o,
                        Get = o.CanRead ? GetValueGetter<TEntity>(o) : null,
                        Set = o.CanWrite ? GetValueSetter<TEntity>(o) : null
                    });
                }                
            }
        }

        #endregion

        public ReadOnlyDictionary<string, Delegate> Methods
        {
            get { return _methods; }
            set { _methods = value; }
        }        

        public object this[string name] 
        {
            get
            {
                return RawView.ContainsKey(name) ? RawView[name] :
                    (RawView[name] = (_accessObjects[name] as AccessObject<TEntity, object>).Get(Raw));
            }
            set
            {
                try
                {
                    RawView[name] = value;
                    (_accessObjects[name] as AccessObject<TEntity, object>).Set(Raw, value);
                    if (PropertyChanged != null)
                        PropertyChanged(Raw, name, value);
                }
                catch (InvalidCastException)
                {
                    var t = Raw.GetType();
                    var p = t.GetProperty(name);
                    p.SetValue(Raw, value);               
                }                
            }
        }

        #region Async

        public Task<object> GetValueAsync(string name)
        {
            return Task.Run(() => this[name]);
        }

        public Task<object> SetValueAsync(string name, object value)
        {
            return Task.Run(() => this[name] = value);
        }

        #endregion


        public object this[TEntity obj, string name]
        {
            get
            {
                return (_accessObjects[name] as AccessObject<TEntity, object>).Get(obj);
            }
            set
            {
                (_accessObjects[name] as AccessObject<TEntity, object>).Set(obj, value);                
            }
        }

        public object this[object obj, string name]
        {
            get
            {
                return (_accessObjects[name] as AccessObject<TEntity, object>).Get((TEntity)obj);
            }
            set
            {
                (_accessObjects[name] as AccessObject<TEntity, object>).Set((TEntity)obj, value);
            }
        }

        public DataProxy<T> GetValueProxy<T>(string name)
        {
            return Create((T)this[name]);
        }

        public bool ContainsProperty(string name)
        {
            return _accessObjects.ContainsKey(name);
        }

        public bool ContainsMethod(string name)
        {
            return _methods.ContainsKey(name);
        }

        public DataProxy<TEntity> Fill(TEntity obj)
        {
            if(obj == null) throw new NullReferenceException();

            return Fill(new DataProxy<TEntity>(obj));
        }

        public DataProxy<TEntity> Fill(TEntity obj, IEnumerable<string> properties)
        {
            if (obj == null) throw new NullReferenceException();

            return Fill(new DataProxy<TEntity>(obj), properties);
        }

        public DataProxy<TEntity> Fill(DataProxy<TEntity> proxy)
        {                                    
            this.AsParallel().ForAll(o => proxy[o] = this[o]);
            return proxy;
        }

        public DataProxy<TEntity> Fill(DataProxy<TEntity> proxy, IEnumerable<string> properties)
        {
            properties.AsParallel().ForAll(o => proxy[o] = this[o]);
            return proxy;
        }

        public event Action<TEntity, string, object> PropertyChanged;

        #region operators

        public static implicit operator TEntity(DataProxy<TEntity> obj)
        {
            return obj.Raw;
        }

        public static implicit operator DataProxy<TEntity>(TEntity obj)
        {
            return new DataProxy<TEntity>(obj);
        }

        #endregion

        public IEnumerator<string> GetEnumerator()
        {
            return _properties.GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }
}
