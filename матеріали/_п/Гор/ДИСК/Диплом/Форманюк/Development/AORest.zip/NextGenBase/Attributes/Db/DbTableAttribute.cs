﻿using System;

namespace NextGenBase.Attributes.Db
{
    [AttributeUsage(AttributeTargets.Class, Inherited = false, AllowMultiple = true)]
    public sealed class DbTableAttribute : Attribute
    {
        public string DbTableName { get; private set; }

        public DbTableAttribute(string name)
        {
            DbTableName = name;
        }        
    }
}
