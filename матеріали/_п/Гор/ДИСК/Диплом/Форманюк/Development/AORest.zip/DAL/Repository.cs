﻿using System.Data.Entity;
using System.Threading.Tasks;
using DAL.Interfaces;

namespace DAL
{
    public class Repository : Entities, IRepository
    {
        IDbSet<T> IRepository.Set<T>()
        {
            return this.Set<T>();
        }

        void IRepository.SaveChanges()
        {            
            this.SaveChanges();
        }

        Task<int> IRepository.SaveChangesAsync()
        {
            return this.SaveChangesAsync();
        }

        void IRepository.Rollback()
        {
            
        }

        Task IRepository.RollbackAsync()
        {
            return Task.Run(() => { ((IRepository)this).Rollback(); });
        }
    }
}