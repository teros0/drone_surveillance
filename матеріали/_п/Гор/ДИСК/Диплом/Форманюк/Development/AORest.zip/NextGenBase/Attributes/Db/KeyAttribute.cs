﻿using System;

namespace NextGenBase.Attributes.Db
{
    [AttributeUsage(AttributeTargets.Property, Inherited = false, AllowMultiple = true)]
    public sealed class KeyAttribute : Attribute
    {
        public string Name { get; private set; }
        public KeyAttribute(string name)
        {
            Name = name;
        }
    }
}
