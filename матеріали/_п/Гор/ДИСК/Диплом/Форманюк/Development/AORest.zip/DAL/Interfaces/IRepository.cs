﻿using System;
using System.Data.Entity;
using System.Threading.Tasks;

namespace DAL.Interfaces
{
    public interface IRepository : IDisposable
    {
        IDbSet<T> Set<T>() where T : class;
        void SaveChanges();
        Task<int> SaveChangesAsync();
        void Rollback();
        Task RollbackAsync();
    }
}