﻿namespace NextGenBase.Interfaces.Factory
{
    public interface IFactory<T>
    {
        T Create();
    }
}