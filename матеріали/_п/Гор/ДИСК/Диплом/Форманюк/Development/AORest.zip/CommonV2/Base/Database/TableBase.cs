﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using CommonV2.Extensions;
using SqliteORM;

namespace CommonV2.Base.Database
{
    [Serializable]
    public static class TableBase<T>
    {        
        public static void Do(Action<TableAdapter<T>> action)
        {
            using (TableAdapter<T> adapter = TableAdapter<T>.Open())
                action(adapter);
        }

        public static TResult Do<TResult>(Func<TableAdapter<T>, TResult> predicate)
        {
            TResult result;
            using (TableAdapter<T> adapter = TableAdapter<T>.Open())
                result = predicate(adapter);
            return result;
        }

        public static Task DoAsync(Action<TableAdapter<T>> action)
        {
            return Task.Run(() => Do(action));
        }

        public static Task<TResult> DoAsync<TResult>(Func<TableAdapter<T>, TResult> predicate)
        {
            return Task.Run(() => Do(predicate));
        }

        public static void Delete(params object[] args)
        {
            using (TableAdapter<T> adapter = TableAdapter<T>.Open())
                adapter.Delete(args);
        }

        public static Task DeleteAsync(params object[] args)
        {
            return Task.Run(() => Delete(args));
        }

        public static T Read(params object[] args)
        {
            using (TableAdapter<T> adapter = TableAdapter<T>.Open())
                return adapter.Read(args);
        }

        public static Task<T> ReadAsync(params object[] args)
        {
            return Task.Run(() => Read(args));
        }

        public static TReturn Get<TReturn>(Func<TableAdapter<T>, TReturn> action) where TReturn : class
        {
            using (TableAdapter<T> adapter = TableAdapter<T>.Open())
                return action(adapter);
        }

        public static Task<TReturn> GetAsync<TReturn>(Func<TableAdapter<T>, TReturn> action) where TReturn : class
        {
            return Task.Run(() => Get(action));
        }

        public static void Insert<T>(T item)
        {
            using (TableAdapter<T> adapter = TableAdapter<T>.Open())
            {
                //adapter.
            }
        }
    }

    public class DbContext<T> : ASingleton<T> //TableAdapter<T>
    {
        private readonly bool _useStrictValidation;
        protected readonly DbTransaction DbTransaction;// = DbTransaction.Open()

        protected readonly ConcurrentQueue<T> Queue;

        protected readonly PropertyInfo[] PkProperties; 
   
        protected DbContext(bool useStrictValidation = true)
        {
            _useStrictValidation = useStrictValidation;
            DbTransaction = DbTransaction.Open();
            Queue = new ConcurrentQueue<T>();

            if (useStrictValidation)
            {
                PkProperties = typeof (T).GetProperties()
                    .Where(o => o.GetCustomAttribute<PrimaryKeyAttribute>() != null)
                    .ToArray();
            }
        }

        public virtual bool Insert(T item)
        {
            if(ValidateObject(item))
                Queue.Enqueue(item);
            else            
                return false;

            return true;
        }

        public virtual IQueryable<T> Select(Func<T, bool> predicate)
        {
            return Queue.Where(predicate).Intersect(TableBase<T>.Do(o => o.Select().Where(predicate))).AsQueryable();
        }

        public virtual Task<IQueryable<T>> SelectAsync(Func<T, bool> predicate)
        {
            return Task.Run(() => Select(predicate));
        }

        public virtual void Save()
        {
            TableBase<T>.Do(adapter => 
            {
                T obj;
                while (Queue.TryDequeue(out obj))                
                    adapter.CreateUpdate(obj);                               
            });

            DbTransaction.Apply(o => o.Commit())
                .Apply(o => o.Dispose())
                .Apply(o => DbTransaction.Open());            
        }

        public Task SaveAsync()
        {
            return Task.Run(() => Save());
        }

        protected bool ValidateObject(T item)
        {            
            if (!_useStrictValidation) return true;
            
            return TableBase<T>.Do(adapter =>
            {
                return Queue.Any(o => PkProperties.Any(p => p.GetValue(item).Equals(p.GetValue(o))))
                         && adapter.Select()
                             .Where(o => PkProperties.Any(p => p.GetValue(item).Equals(p.GetValue(o))))
                             .Any();
            });           
        }
    }
}
