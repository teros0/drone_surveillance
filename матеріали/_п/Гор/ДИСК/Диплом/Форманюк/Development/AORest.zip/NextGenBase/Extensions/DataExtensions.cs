﻿using System.Data.Entity;
using System.Net.Http;
using jetMapper;
using NextGenBase.Helpers;

namespace NextGenBase.Extensions
{
    public static class DataExtensions
    {
        public static DataProxy<T> Proxy<T>(this T obj) where T : class
        {
            return DataProxy.Create(obj);
        }

        public static string ContentToString(this HttpContent httpContent)
        {
            var readAsStringAsync = httpContent.ReadAsStringAsync();
            return readAsStringAsync.Result;
        }
    }
}