﻿using System;

namespace CommonV2.Extensions
{
    public static class ObjectExtensions
    {
        /// <summary>
        /// <para>The same as to do (T)object but in more clear manner</para>
        /// <para>Doing in this way allows us to continue 'dotting' instead of doing something like ((T)obj).property</para>
        /// </summary>
        public static T As<T>(this object obj)
        {
            return (T)obj;
        }

        /// <summary>
        /// Allows to manipulate the object in the chain manner.
        /// </summary>
        /// <returns></returns>
        public static T Apply<T>(this T source, Action<T> action) where T : class
        {
            action(source);
            return source;
        }

        public static T Apply<T>(this T source, Func<T, T> action) where T : struct 
        {
            return action(source);
        }

        #region If

        /// <summary>
        /// Allows to perform some action depending on condition in chain style. Will be executed if chained value is 'true'
        /// </summary>
        /// <returns></returns>
        public static bool True(this bool condition, params Action[] actions)
        {
            if (condition) actions.ForEach(a => a());
            return condition;
        }

        /// <summary>
        /// Allows to perform some action depending on condition in chain style. Will be executed if chained value is 'false'
        /// </summary>
        /// <returns></returns>
        public static bool False(this bool condition, params Action[] actions)
        {
            if (!condition) actions.ForEach(a => a());
            return condition;
        }

        #endregion
    }
}
