﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Controllers;
using System.Web.Mvc;
using System.Web.Routing;
using jetMapper.Extensions;
using NextGenBase.Extensions;
using NextGenBase.Interfaces;
using RAMLSharp.Attributes;
using RouteCollectionExtensions = System.Web.Mvc.RouteCollectionExtensions;

namespace NextGenBase.Attributes.Routing
{
    [AttributeUsage(AttributeTargets.Method | AttributeTargets.Class)]
    public sealed class RouteAttribute : Attribute
    {
        public string Name { get; private set; }
        public Type Interface { get; private set; }
        public string Route { get; private set; }              
        public string Namespaces { get; set; }

        /// <summary>
        /// <para>Initializes a new instance of the <see cref="RouteAttribute"/> class.</para>
        /// <para>Applicable for method only!</para>
        /// </summary>
        /// <param name="name">Name of the route</param>
        /// <param name="interface">Routed method type</param>
        /// <param name="route"></param>
        public RouteAttribute(string name, Type @interface, string route)
        {
            Name = name;
            Interface = @interface;
            Route = route.TrimStart('/');            
        }

        /// <summary>
        /// <para>Initializes a new instance of the <see cref="RouteAttribute"/> class.</para>
        /// <para>Applicable for class only!</para>
        /// </summary>
        /// <param name="name">Name of the route</param>
        /// <param name="route"></param>
        public RouteAttribute(string name, string route)
        {
            Name = name;            
            Route = route.TrimStart('/');
        } 

        public void MapMvcRoute<T, TData>(RouteCollection config, Type controller, string startPoint = "") 
            where T : IController, IRESTfull<TData>
        {
            var disableAttrs = controller.GetCustomAttributes<DisableRoutesAttribute>().ToArray();
            if (disableAttrs.Any())
            {
                if (!disableAttrs.Where(o => o.RouteInterface != this.Interface)
                    .Where(o => !this.Interface.GetInterfaces().Contains(o.RouteInterface))
                    .Any())
                    return;
            }

            var cntrl = controller.Name.Replace("Controller", String.Empty);

            switch (Name)
            {
                case "GetPropertyAction":
                    {
                        config.TypedRoute(Route.Replace("{controller}", cntrl), c => c.MvcController<T>().Action<T>(x => x.GetPropertyAction(Param.Any<HttpRequestMessage>(), Param.Any<int>(), Param.Any<string>())));
                        return;
                    }
                case "GetByIdAction":
                    {
                        config.TypedRoute(Route.Replace("{controller}", cntrl), c => c.MvcController<T>().Action<T>(x => x.GetByIdAction(Param.Any<HttpRequestMessage>(), Param.Any<int>())));
                        return;
                    }
                case "GetAllAction":
                    {
                        config.TypedRoute(Route.Replace("{controller}", cntrl), c => c.MvcController<T>().Action<T>(x => x.GetAllAction(Param.Any<HttpRequestMessage>())));
                        return;
                    }
                //case "AddAction":
                //    {
                //        config.TypedRoute(Route.Replace("{controller}", cntrl), c => c.MvcController<T>().Action<T>(x => x.AddAction(Param.Any<HttpRequestMessage>(), Param.Any<TData>())));
                //        return;
                //    }
            }

            dynamic data = new ExpandoObject();

            IDictionary<string, object> dictionary = (IDictionary<string, object>)data;            
            dictionary.Add("action", Name);

            var reg = new Regex(@"\{([a-zA-Z]+)\}");
            var matches = reg.Matches(Route);
            foreach (Match match in matches)
            {
                dictionary.Add(match.Groups[1].Value, RouteParameter.Optional);
            }

            RouteCollectionExtensions.MapRoute(config, 
                name: Name + Route + "MVC",
                url: startPoint + Route.Replace("{controller}", cntrl), 
                defaults: data);
        }

        public static class Param
        {
            public static TValue Any<TValue>()
            {
                return default(TValue);
            }
        }

        public void MapHttpRoute<T, TData>(Type controller, MethodInfo method, HttpConfiguration config, string startPoint = "")
            //where T : IRESTfull<TData>, IHttpController
            where T : IHttpController
        {
            var disableAttrs = controller.GetCustomAttributes<DisableRoutesAttribute>().ToArray();
            if (disableAttrs.Any())
            {
                if (!disableAttrs.Where(o => o.RouteInterface != this.Interface)
                    .Where(o => !this.Interface.GetInterfaces().Contains(o.RouteInterface))
                    .Any())
                return;
            }

            var cntrl = controller.Name.Replace("Controller", String.Empty);

            var controllerVersionAttr = controller.GetCustomAttribute<VersionAttribute>(true);
            if (controllerVersionAttr != null)
            {
                Route = controllerVersionAttr.StringRepresentation + "/" + Route;
            }
            else
            {
                var methodVersionAttr = method.GetCustomAttribute<VersionAttribute>(true);
                if (methodVersionAttr != null)
                {
                    Route = methodVersionAttr.StringRepresentation + "/" + Route;
                }   
            }

            var attr = method.GetCustomAttributes<ResponseBodyAttribute>(true)
                .SingleOrDefault(o => o.StatusCode == HttpStatusCode.OK);
            if (attr != null)
                attr.Apply(o =>
                {
                    o.Example = CRUDProvider.TypeOfView;
                });

            var controllerRouteAttr = controller.GetCustomAttribute<RouteAttribute>(true);
            Route = Route.Replace("{controller}", controllerRouteAttr.Route);

            Route = Route.Replace("{controller}",
                !string.IsNullOrEmpty(controllerRouteAttr.Name) ? controllerRouteAttr.Name : cntrl);

            config.TypedRoute(Route, c => c.Controller<T>().Action(method));               
        }
    }
}
