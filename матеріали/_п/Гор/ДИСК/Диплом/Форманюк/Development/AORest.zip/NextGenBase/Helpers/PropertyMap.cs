﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NextGenBase.Helpers
{
    public class PropertyMap
    {
        public string Model { get; set; }
        public string Entity { get; set; }
    }
}
