﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using jetMapper.Extensions;
using NextGenBase.Attributes.Routing;
using NextGenBase.Helpers;
using NextGenBase.Interfaces;

namespace NextGenBase
{
    public abstract partial class CRUDProvider<T, TEntity>
    {
        #region Post        

        [System.Web.Http.AcceptVerbs("POST")]
        [Route("AddMultipleAction", typeof (IRESTPost<>), "/{controller}")]
        public virtual Task<HttpResponseMessage> AddMultipelAction(HttpRequestMessage request)
        {
            var content = request.Content.ReadAsStringAsync()
                .ContinueWith(task => 
                    Parser.ToEnumerable<T>(task.Result));

            return ValidateAndInvokeAsync(request, async (ActionContainer<IEnumerable<T>> container) =>
            {
                try
                {
                    var enumerable = await content;

                    if (enumerable == null)
                    {
                        container.AddError(new NullReferenceException("Data cannot be null"));
                        return null;
                    }

                    var addActionResults = enumerable.Select(o => _singleAddAction(request, o, container));

                    if (!container.Success)
                    {
                        Repository.Rollback();
                        return null;
                    }

                    Repository.SaveChanges();

                    return addActionResults.Select(o => DataService.Map<TEntity, T>(o));
                }
                catch (Exception e)
                {
                    Repository.Rollback();
                    container.AddError(e);
                    return null;
                }
            },
                HttpStatusCode.Created,
                Repository.Rollback,
                InterfaceTypes[Interface.Post]);
        }        

        private TEntity _singleAddAction(HttpRequestMessage request, T obj, ActionContainer<IEnumerable<T>> container)
        {
            var validationResult = _post(obj);
            if (validationResult.Success)
            {
                return DataProvider.Add(DataService.Map<T, TEntity>(obj));
            }
            else
            {                
                container.AddError(
                    new InvalidOperationException(
                        "Action cannot be performed due to error!",
                        new AggregateException(validationResult.Errors.Select(error => new Exception(error)))));
                return null;
            }            
        }

        private ActionContainer<T> _post(T obj)
        {
            return _chainInvoker<ActionContainer<T>>(typeof (IRESTPost<T>), obj)
                .Apply(o => ControllerMetadatas[GetType()].CustomeServicesChain[InterfaceTypes[Interface.Get]](o));
        }

        #endregion 
    }
}