﻿using System;
using System.Collections.Generic;

namespace NextGenBase.Interfaces.Servises
{
    public interface IServiceProvider
    {
        T GetService<T>() where T : class, IService;
        void ReleaseService<T>() where T : class, IService;
        Dictionary<Type, IService> Services { get; set; } 
    }
}