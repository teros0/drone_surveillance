﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using jetMapper;
using NextGenBase.Extensions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NextGenBase.Helpers;

namespace NextGenBase.Extensions.Tests
{
    [TestClass()]
    public class DelegateHelperTests
    {
        [TestMethod()]
        public void CreateCompatibleDelegateTest()
        {            
            Stopwatch w = new Stopwatch();
            Stopwatch s = new Stopwatch();
            Stopwatch r = new Stopwatch();
            
            LinkedList<ActionContainer<int>> lst = new LinkedList<ActionContainer<int>>();

            var tt = new ActionContainer<double>().Proxy();
            tt["rr"] = 2;

            var ttt = tt.Generate<ActionContainer<double>>();
            var q = ttt.Proxy()["rr"];

            var proxy = DataProxy.Create<ActionContainer<int>>();
            w.Start();            
            for (int i = 0; i < 100000; i++)
            {                
                var t = new ActionContainer<int>();
                proxy[t, "Value"] = i;                
                //lst.AddLast(t);
            }  
            w.Stop();

            LinkedList<ActionContainer<int>> lst1 = new LinkedList<ActionContainer<int>>();

            s.Start();
            for (int i = 0; i < 100000; i++)
            {
                var t = new ActionContainer<int>();// {Value = i};
                t.Value = i;
                //lst1.AddLast(t);
            }  
            s.Stop();

            LinkedList<ActionContainer<int>> lst2 = new LinkedList<ActionContainer<int>>();

            var p = typeof(ActionContainer<int>).GetProperty("Value", typeof(int));
            r.Start();            
            for (int i = 0; i < 100000; i++)
            {
                var t = new ActionContainer<int>();                
                p.SetValue(t, i);
                lst2.AddLast(t);
            }
            r.Stop();

            Assert.IsTrue(w.ElapsedTicks < s.ElapsedTicks, string.Format("w: {0}, s: {1}", w.ElapsedMilliseconds, s.ElapsedMilliseconds));
            //Assert.AreEqual(100000 - 1, lst.Last.Value.Value);
        }

        [TestMethod()]
        public void PipeFuncsStructsTest()
        {            
            Func<int, int> func = i => i * i;
            var tt = func.X() >
                    (o => o + 1)
                    > (o => o + 2);
            var r = tt.Do(2);

            Assert.AreEqual(7, r);
        }

        [TestMethod()]
        public void PipeFuncsClassesTest()
        {
            StringBuilder builder = new StringBuilder();

            Func<StringBuilder, StringBuilder> func = i => i;
            var tt = func.X() >
                    (o => o.Append("123"))
                    > (o => o.Append("456"));
            var r = tt.Do(builder);

            Assert.AreEqual(builder.ToString(), "123456");
        }

        [TestMethod()]
        public void PipeFuncDelegateTest()
        {
            StringBuilder builder = new StringBuilder();

            Func<StringBuilder, StringBuilder> func = i => i;
            Func<StringBuilder, StringBuilder> func2 = i => i.Append("789");

            var tt = func.X() >
                    (o => o.Append("123")) > (o => o.Append("456")) > func2;
            var r = tt.Do(builder);

            Assert.AreEqual(builder.ToString(), "123456789");
        }

        [TestMethod()]
        public void PipeFuncNullTest()
        {
            StringBuilder builder = new StringBuilder();

            Func<StringBuilder, StringBuilder> func = null;
            Func<StringBuilder, StringBuilder> func2 = i => i.Append("789");

            var tt = func.X() >
                    (o => o.Append("123")) > (o => o.Append("456")) > func2;
            var r = tt.Do(builder);

            Assert.AreEqual(builder.ToString(), "123456789");
        }
    }
}
