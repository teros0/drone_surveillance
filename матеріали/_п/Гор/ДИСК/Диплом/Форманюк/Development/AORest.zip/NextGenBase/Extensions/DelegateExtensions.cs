﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Threading;
using jetMapper;
using NextGenBase.Helpers;

namespace NextGenBase.Extensions
{    
    public static class DelegateHelper
    {
        public static Linker<T> X<T>(this Func<T, T> @delegate)
        {
            return new Linker<T>(@delegate);
        }        
    }
}