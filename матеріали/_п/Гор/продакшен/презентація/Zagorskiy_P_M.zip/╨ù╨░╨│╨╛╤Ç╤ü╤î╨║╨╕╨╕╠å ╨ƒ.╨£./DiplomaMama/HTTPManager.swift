//
//  HTTPManager.swift
//  DiplomaMama
//
//  Created by Pavel Zagorskyy on 09.05.15.
//  Copyright (c) 2015 zagorskyy.com. All rights reserved.
//

import UIKit

class HTTPManager: NSObject {
    
    let domain = "http://campus-api.azurewebsites.net/"
    
    class var sharedInstance : HTTPManager {
        struct Static {
            static let instance : HTTPManager = HTTPManager()
        }
        return Static.instance
    }
    
    func receivePostDataFor(command:String, parameters:AnyObject?, success:(json: AnyObject) -> (), failure:(json: NSError) -> ()) -> AFHTTPRequestOperation {
        return AFHTTPRequestOperationManager().POST(domain + command, parameters: parameters, success: {(operation: AFHTTPRequestOperation!, responseObject: AnyObject!) in
            success(json: responseObject)
            }, failure: {(operation: AFHTTPRequestOperation!, error: NSError!) in
                failure(json: error)
        })
    }
    
    func receiveGetDataFor(command:String, parameters:AnyObject?, success:(json: AnyObject) -> Void, failure:(json: AnyObject?) -> Void) -> AFHTTPRequestOperation {
        return AFHTTPRequestOperationManager().GET(domain + command, parameters: parameters, success: {(operation: AFHTTPRequestOperation!, responseObject: AnyObject!) in
            success(json: responseObject)
            }, failure: {(operation: AFHTTPRequestOperation!, error: NSError!) in
                failure(json: ["error":error])
        })
    }
   
}
