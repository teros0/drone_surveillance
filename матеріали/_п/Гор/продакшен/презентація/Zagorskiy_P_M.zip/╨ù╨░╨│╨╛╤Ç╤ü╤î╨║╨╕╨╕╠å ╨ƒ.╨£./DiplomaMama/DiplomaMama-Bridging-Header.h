//
//  DiplomaMama-Bridging-Header.h
//  DiplomaMama
//
//  Created by Pavel Zagorskyy on 09.05.15.
//  Copyright (c) 2015 zagorskyy.com. All rights reserved.
//

#ifndef DiplomaMama_DiplomaMama_Bridging_Header_h
#define DiplomaMama_DiplomaMama_Bridging_Header_h

#import "AFNetworking.h"

#endif
