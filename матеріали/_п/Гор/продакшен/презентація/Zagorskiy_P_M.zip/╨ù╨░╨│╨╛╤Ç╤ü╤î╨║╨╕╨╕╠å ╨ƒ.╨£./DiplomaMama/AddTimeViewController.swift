//
//  AddTimeViewController.swift
//  DiplomaMama
//
//  Created by Pavel Zagorskyy on 10.06.15.
//  Copyright (c) 2015 zagorskyy.com. All rights reserved.
//

import UIKit

class AddTimeViewController: UIViewController {

    @IBOutlet weak var buttonSave: UIButton!
    @IBOutlet weak var fifthButton: UILabel!
    @IBOutlet weak var secondButton: UILabel!
    @IBOutlet weak var firstButton: UILabel!
    @IBOutlet weak var thirdButton: UILabel!
    @IBOutlet weak var fourthButton: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        makeMyLayer(firstButton.layer)
        makeMyLayer(secondButton.layer)
        makeMyLayer(thirdButton.layer)
        makeMyLayer(fourthButton.layer)
        makeMyLayer(fifthButton.layer)
        
        makeButtonLayer(buttonSave.layer)

    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
//    
//    func makeMySpecialLayer(layer: CALayer) {
//        layer.cornerRadius = firstButton.frame.height / 2
//        layer.borderWidth = 1
//        layer.borderColor = UIColor.whiteColor().CGColor
//        layer.masksToBounds = true
//    }
    
    func makeMyLayer(layer: CALayer) {
        layer.cornerRadius = firstButton.frame.height / 2
        layer.borderWidth = 1
        layer.borderColor = UIColor.whiteColor().CGColor
        layer.masksToBounds = true
    }
    
    func makeButtonLayer(layer: CALayer) {
        layer.cornerRadius = 15
        layer.borderWidth = 1
        layer.borderColor = UIColor.whiteColor().CGColor
        layer.masksToBounds = true
    }
}
