//
//  ProfileViewController.swift
//  DiplomaMama
//
//  Created by Pavel Zagorskyy on 17.05.15.
//  Copyright (c) 2015 zagorskyy.com. All rights reserved.
//

import UIKit

class ProfileViewController: UIViewController {
    @IBOutlet weak var avatar: UIImageView!
    @IBOutlet weak var contactsView: UIView!
    @IBOutlet weak var editButton: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        makeLayer(avatar.layer, cornerRadius: avatar.frame.width / 2, borderWidth: 1)
        makeLayer(contactsView.layer, cornerRadius: 5, borderWidth: 0)
        makeLayer(editButton.layer, cornerRadius: editButton.frame.height / 2, borderWidth: 1)

    }
    
    func makeLayer(layer: CALayer, cornerRadius: CGFloat, borderWidth: CGFloat) {
        layer.cornerRadius = cornerRadius
        layer.borderWidth = borderWidth
        layer.borderColor = UIColor(red: 33/255, green: 137/255, blue: 68/255, alpha: 1).CGColor
        layer.masksToBounds = true
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
