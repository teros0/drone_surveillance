//
//  SettingsViewController.swift
//  DiplomaMama
//
//  Created by Pavel Zagorskyy on 10.06.15.
//  Copyright (c) 2015 zagorskyy.com. All rights reserved.
//

import UIKit

class SettingsViewController: UIViewController {

    @IBOutlet weak var save: UIButton!
    @IBOutlet weak var changeColor: UIButton!
    @IBOutlet weak var changeLang: UIButton!
    @IBOutlet weak var clearCache: UIButton!
    @IBOutlet weak var english: UIButton!
    @IBOutlet weak var russian: UIButton!
    @IBOutlet weak var ukrainian: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()

        makeRound(clearCache.layer, borderColor: UIColor.whiteColor(), borderWidth: 1, radius: 15)
        makeRound(changeLang.layer, borderColor: UIColor.whiteColor(), borderWidth: 1, radius: 15)
        makeRound(changeColor.layer, borderColor: UIColor.lightGrayColor(), borderWidth: 1, radius: 15)
        makeRound(save.layer, borderColor: UIColor.whiteColor(), borderWidth: 1, radius: 10)
        
        makeRound(english.layer, borderColor: UIColor.whiteColor(), borderWidth: 1, radius: english.frame.height / 2)
        makeRound(russian.layer, borderColor: UIColor.whiteColor(), borderWidth: 1, radius: english.frame.height / 2)
        makeRound(ukrainian.layer, borderColor: UIColor.whiteColor(), borderWidth: 1, radius: english.frame.height / 2)

        



    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()

    }
    
    
    func makeRound(layer: CALayer, borderColor: UIColor, borderWidth: CGFloat, radius: CGFloat) {
        
        layer.masksToBounds = true
        layer.borderWidth = borderWidth
        layer.borderColor = borderColor.CGColor
        layer.cornerRadius = radius
    }
    



}
