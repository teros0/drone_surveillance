//
//  ScheduleViewController.swift
//  DiplomaMama
//
//  Created by Pavel Zagorskyy on 19.05.15.
//  Copyright (c) 2015 zagorskyy.com. All rights reserved.
//

import UIKit

class ScheduleViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var addTimeButton: UIButton!
    @IBOutlet weak var chooseDay: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.registerNib(UINib(nibName: "MainTableViewCell", bundle: nil), forCellReuseIdentifier: "scheduleCell")
        NSBundle.mainBundle().loadNibNamed("CustomHeader", owner: nil, options: nil)
        makeButtonRound(addTimeButton.layer)
        makeButtonRound(chooseDay.layer)
        
    }
    
    func makeButtonRound(layer: CALayer) {
        layer.masksToBounds = true
        layer.borderWidth = 1
        layer.borderColor = UIColor.whiteColor().CGColor
        layer.cornerRadius = 7
        
    }
    
    // MARK: - Table view data source
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Potentially incomplete method implementation.
        // Return the number of sections.
        return 5
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {

        return 4
    }
    
     func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> MainTableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("scheduleCell", forIndexPath: indexPath) as MainTableViewCell
        cell.subjectNumber.layer.cornerRadius = cell.subjectNumber.frame.width / 2
        cell.subjectNumber.layer.borderColor = UIColor(red: 33/255, green: 137/255, blue: 68/255, alpha: 1).CGColor
        cell.subjectNumber.layer.borderWidth = 1
        cell.subjectNumber.layer.masksToBounds = true
        cell.subjectNumber.text = String(indexPath.item+1)
        
//        @IBOutlet weak var timeLabel: UILabel!
//        @IBOutlet weak var subjectName: UILabel!
//        @IBOutlet weak var subjectNumber: UILabel!
//        @IBOutlet weak var teacherName: UILabel!
//        @IBOutlet weak var roomNumber: UILabel!
//        @IBOutlet weak var lessonType: UILabel!
        
        if indexPath.item == 0 {
            cell.subjectName.text = "Основи охорони праці"
            cell.teacherName.text = "Сидорченко Іванна Павлівна"
            cell.roomNumber.text = "307-18"
            cell.lessonType.text = "Лекція"
        } else if indexPath.item == 1 {
            cell.timeLabel.text = "10:25\n11:55"
            cell.subjectName.text = "Управління технічними\nсистемами - 2.Цифрові\nсистеми управління"
            cell.teacherName.text = "Іваненко Олександр Андрійович"
            cell.roomNumber.text = "418а-18"
            cell.lessonType.text = "Лекція"
        } else if indexPath.item == 2 {
            cell.timeLabel.text = "12:20\n13:40"
            cell.subjectName.text = "Комп'ютерні навчаючі\nсистеми"
            cell.teacherName.text = "Дмітрієва Антоніна Андріївна"
            cell.roomNumber.text = "419-18"
            cell.lessonType.text = "Лекція"
        } else if indexPath.item == 3 {
            cell.timeLabel.text = ""
            cell.subjectName.text = ""
            cell.teacherName.text = ""
            cell.roomNumber.text = ""
            cell.lessonType.text = ""
        }

        
        
//        if indexPath.item == 0 {
//        } else if indexPath.item == 1 {
//            cell.timeLabel.text = "10:25\n11:55"
//            cell.subjectName.text = "Укр мова за профессійним\nспрямуванням"
//            cell.teacherName.text = "Тільняк Неоніла Василівна"
//            cell.roomNumber.text = "419-18"
//            cell.lessonType.text = "Практика"
//        } else if indexPath.item == 2 {
//            cell.timeLabel.text = "12:20\n13:40"
//            cell.subjectName.text = "Комп'ютерні навчаючі\nсистеми"
//            cell.teacherName.text = "Польшакова Ольга Михайлівна"
//            cell.roomNumber.text = "419-18"
//            cell.lessonType.text = "Лекція"
//        } else if indexPath.item == 3 {
//            cell.timeLabel.text = "14:05\n15:35"
//            cell.subjectName.text = "Комп'ютерні навчаючі\nсистеми"
//            cell.teacherName.text = "Польшакова Ольга Михайлівна"
//            cell.roomNumber.text = "418а-18"
//            cell.lessonType.text = "Практика"
//        }
        
        // Configure the cell...
        
        return cell
    }
    
     func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 135
    }
    
     func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        var headerView = UIView(frame: CGRectMake(0, 0, tableView.frame.width, 40))
        var label = UILabel(frame: CGRectMake(20, 0, tableView.frame.width, 40))
        label.text = "Понеділок 25.05"
        label.textColor = UIColor.whiteColor()
        label.backgroundColor = UIColor.clearColor()
        headerView.addSubview(label)
        headerView.backgroundColor = UIColor(red: 33/255, green: 137/255, blue: 68/255, alpha: 1)
        
        if section == 0 {
            label.text = "Понеділок 25.05"
        } else if section == 1 {
            label.text = "Вівторок 26.05"
        } else if section == 2 {
            label.text = "Середа 27.05"
        } else if section == 3 {
            label.text = "Четвер 28.05"
        } else if section == 4 {
            label.text = "П'ятниця 29.05"
        }
        
        return headerView
    }
    
     func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        
        return 40
    }
    
     func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        self.performSegueWithIdentifier("detailSchedule", sender: nil)
    }

    @IBAction func addTimeAction(sender: AnyObject) {
        
    }
    
    @IBAction func chooseDayAction(sender: AnyObject) {
        
    }
}
