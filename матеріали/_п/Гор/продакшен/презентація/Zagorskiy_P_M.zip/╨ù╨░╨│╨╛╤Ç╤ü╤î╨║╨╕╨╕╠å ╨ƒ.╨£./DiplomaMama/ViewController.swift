//
//  ViewController.swift
//  DiplomaMama
//
//  Created by Pavel Zagorskyy on 09.05.15.
//  Copyright (c) 2015 zagorskyy.com. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var loginTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var guestButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        guestButton.layer.borderWidth = 1
        guestButton.layer.borderColor = UIColor.whiteColor().CGColor
        guestButton.layer.cornerRadius = 7
        guestButton.layer.masksToBounds = true
        
        loginButton.layer.borderWidth = 1
        loginButton.layer.borderColor = UIColor.whiteColor().CGColor
        loginButton.layer.cornerRadius = 7
        loginButton.layer.masksToBounds = true
        
        getSessionId("2", password: "21")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func loginAction(sender: AnyObject) {
        println("dadsdsd")
        UIAlertView(title: "Login Successful", message: "Do yo want to save your login and password?", delegate: nil, cancelButtonTitle: "No", otherButtonTitles: "Yes").show()
        getSessionId(loginTextField.text, password: passwordTextField.text)
    }
    
    func getSessionId(login: String, password: String) -> String {
       
        let httpManager = HTTPManager.sharedInstance
        var parameters: [String:AnyObject] =
        [
            "login": login,
            "password" : password
        ]
        
        httpManager.receiveGetDataFor("User/Auth", parameters: parameters, success: { (json) -> Void in
            
            
            let dictionary = json as NSDictionary
            println(dictionary)

            let sessionId = dictionary["Data"] as String
            println(sessionId)

            
        }) { (json) -> Void in
            println("error")
        }
        
        return "123"
    }

    @IBAction func guestAction(sender: AnyObject) {
        
        UIAlertView(title: "Logged in as guest", message: "You are logged in as guest, if you want to use all functionality of app, you need to log in.", delegate: nil, cancelButtonTitle: "Ok").show()
    }

}

