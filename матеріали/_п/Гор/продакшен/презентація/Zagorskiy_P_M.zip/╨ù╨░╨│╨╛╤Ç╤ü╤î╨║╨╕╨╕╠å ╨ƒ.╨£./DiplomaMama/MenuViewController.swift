//
//  MenuViewController.swift
//  DiplomaMama
//
//  Created by Pavel Zagorskyy on 17.05.15.
//  Copyright (c) 2015 zagorskyy.com. All rights reserved.
//

import UIKit

class MenuViewController: UIViewController {
    @IBOutlet weak var scheduleButton: UIButton!
    @IBOutlet weak var profileButton: UIButton!
    @IBOutlet weak var settingsButton: UIButton!
    @IBOutlet weak var synhronizeButton: UIButton!
    @IBOutlet weak var teachersButton: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        makeButtonRound(scheduleButton)
        makeButtonRound(profileButton)
        makeButtonRound(settingsButton)
        makeButtonRound(synhronizeButton)
        makeButtonRound(teachersButton)


    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func makeButtonRound(button: UIButton) {
        button.layer.cornerRadius = 7
        button.layer.borderWidth = 1
        button.layer.borderColor = UIColor.whiteColor().CGColor
        button.layer.masksToBounds = true
    }

}
